<!DOCTYPE HTML>
<html>

<head>
    <title>Nghĩa Trang Online</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script src="js/login.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/51b7f16ab3.js" crossorigin="anonymous"></script>

    <link rel="icon" href="images/icon.png">
</head>
<?php  include "ConnectDatabase.php"; ?>

<body>
    <div class="footer">
        <div class="wrap">
            <div class="header-top">
                <div class="header-left">

                    <div class="cssmenu">
                        <ul>
                            <li><a href="trangchu.php"><span>Trang Chủ</span></a></li>
                            <!-- <li class=""><a href="khumo.php"><span>Khu Mộ</span></a></li> -->
                            <!-- <li><a href="services.html"><span>Quy Định</span></a></li> -->
                            <!-- <li class="has-sub"><a href="work.html"><span>My Work</span></a></li> -->
                            <!-- <li class="last"><a href="contact.html"><span>Liên Hệ</span></a></li> -->
                            <div class="clear"></div>
                        </ul>
                    </div>
                </div>
                <div class="header-right">
                    <!-- <div id="loginContainer">
				 <span>Join NewsLetter Here.Ma Pimps</span><a id="loginButton"><img src="images/plus.png" alt="" /></a>
				     <div id="loginBox">                
				          <form id="loginForm">
				             <div>
						    	<span><label>E-Mail</label></span>
						    	<span><input name="userEmail" type="text" class="textbox"></span>
						     </div>
							 <div>
						   		<span><input type="submit" value="Subscribe"></span>
						     </div>
						    
					      </form>
				      </div>
			    </div> -->
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
    <div class="product-main">
        <div class="wrap">
            <ul class="breadcrumb">
                <li><a href="trangchu.php">Trang Chủ</a></li>
                <li><a href="vanan-Phat.php">Khu Mộ Vạn An - Đức Phật</a></li>
                <li>Lập Mộ</li>
                <!-- <li><a href="#">Summer 15</a></li>
  <li>Italy</li>-->
            </ul>
            <div class="section group">
                <div class="col span_2_of_3 ">
                    <div class="contact-form">
                        <h3>Lập Mộ Mới</h3>
                        <form method="post">
                            <!-- <div>
						    	<span><label>Số Mộ <i class="batbuoc">(*)</i></label></span>
						    	<span>
								<input name="userId" type="text" class="textbox" value="<?php $idd= $_GET['id']; echo $idd;?>" disabled ></span>
                            </div> -->
                            <!-- <div>
                                <span><label>Tên Thánh<i class="batbuoc">(*)</i></label></span>
                                <span><input name="userThanh" type="text" class="textbox" placeholder="Tối đa 30 ký tự"
                                        id="userThanh" maxlength="30"></span>
                            </div> -->
                            <div>
                                <span><label>Tên người đã khuất</label></span>
                                <span><input name="userTen" type="text" class="textbox" placeholder="Tối đa 30 ký tự"
                                        id="userTen" maxlength="30"></span>
                            </div>
                            <div>
                                <span><label>E-Mail <i class="batbuoc">(*)</i></label></span>
                                <span><input name="userEmail" type="email" class="textbox" placeholder="Tối đa 50 ký tự"
                                        maxlength="50"></span>
                            </div>
                            <div>
                                <span><label>Ngày tháng năm sinh</label></span>
                                <span><input name="userNgaysinh" type="text" class="textbox"
                                        placeholder="Tối đa 10 ký tự" maxlength="10"></span>
                            </div>
                            <div>
                                <span><label>Ngày tháng năm mất</label></span>
                                <span><input name="userNgaymat" type="date" class="textbox"
                                        placeholder="Tối đa 10 ký tự" maxlength="10"></span>
                            </div>
                            <div>
                                <span><label>Quê Quán</label></span>
                                <span><input name="userQuequan" type="date" class="textbox"
                                        placeholder="Tối đa 30 ký tự" maxlength="30"></span>
                            </div>
                            <div>
                                <span><label>Người Lập Mộ</label></span>
                                <span><input name="userNguoilap" type="text" class="textbox"
                                        placeholder="Tối đa 30 ký tự" maxlength="30"></span>
                            </div>

                            <div>
                                <span><label>Mật Khẩu Quản Lý Mộ <i class="batbuoc">(*)</i></label></span>
                                <span><input name="userMatKhau" type="password" class="textbox"
                                        placeholder="Tối đa 10 ký tự" id="userMatKhau" maxlength="10"></span>
                                <span><input type="checkbox" onclick="myFunction()" />Hiển Thị Mật Khẩu <i
                                        id="eye"></i></span>
                                <script>
                                function myFunction() {
                                    var x = document.getElementById("userMatKhau");

                                    if (x.type === "password") {
                                        x.type = "text";
                                        document.getElementById("eye").innerHTML = "<i class='fas fa-eye'></i>";
                                    } else {
                                        x.type = "password";
                                        document.getElementById("eye").innerHTML = "<i class='fas fa-eye-slash'></i>";
                                    }
                                }
                                </script>
                            </div>

                            <div>


                                <span><label>Hình Mộ</label></span>

                                <span id="imgg" class="checkhinh" name="imgg">
                                <label>
                                        <input type="radio" name="hinh" value="1.jpg" checked>
                                        <img src="images/1.jpg">
                                    </label>
                                   
                                    <label>
                                        <input type="radio" name="hinh" value="3.jpg">
                                        <img src="images/3.jpg">
                                    </label>
                                    <label>
                                        <input type="radio" name="hinh" value="5.jpg">
                                        <img src="images/5.jpg">
                                    </label>
                                    <label>
                                        <input type="radio" name="hinh" value="6.jpg">
                                        <img src="images/6.jpg">
                                    </label>
                                    <label>
                                        <input type="radio" name="hinh" value="7.jpg">
                                        <img src="images/7.jpg">
                                    </label>
                                   

                                </span>

                            </div>
                            <div class="clear"></div>

                            <div class="clear"></div>
                            <br>
                            <br>
                            <div>
                                <span><input type="submit" value="Thêm Mộ" name="ThemMo" id="ThemMo"></span><br>
                                <div class="clear"></div>
                                <div class="clear"></div>

                                <div class="clear"></div>
                            </div>
                        </form>
                        <!-- UpLoad	 File  -->

                        
                        <br>
                        <div class="clear"></div>


                        <div>
                            <b>+ Ô nhập có <i class="batbuoc">(*)</i> bắt buộc không được để trống</b> <br>
                            <b>+ Mộ đã lập sẽ được lưu vĩnh viễn trên website này, được lưu trữ an toàn mỗi ngày,
                                trừ khi người lập mộ tự xóa bằng mật khẩu của mình hoặc chúng tôi phát hiện mộ đã
                                lập vi phạm các điều lệ của website, mạo danh người quá cố gây ảnh hưởng chung đến
                                khu mộ</b>
                        </div>

                        <!---Insert Mo-->
                        <?php
						 $dao="Thiên Chúa";
						if(isset($_POST['ThemMo'])){
							// lấy thông tin lập mộ
							$IDd = $_GET['id'];
							$name= $_POST['userTen'];
							$emailA= $_POST['userEmail'];
							$ngaysinh= $_POST['userNgaysinh'];
							$ngaymat= $_POST['userNgaymat'];
							$quequan= $_POST['userQuequan'];
							$nguoilap= $_POST['userNguoilap'];
							$matkhau =$_POST['userMatKhau'];
							$hinh =$_POST['hinh'];
                            
                            $tenthanh=$_POST['userThanh'];
							
							if($IDd==""|| $emailA=="" || $tenthanh==""|| $matkhau==""){
								echo "Vui lòng nhập đầy đủ thông tin";
							}else {
								$sql=( "INSERT INTO mo(ID,Thanh,TenNguoiKhuat, Email, NgayThangNamSinh, NgayThangNamMat, QueQuan, NguoiLapMo,MatKhau,Hinh,HinhBia,Dao) 
								VALUES ('','$name','$tenthanh','$emailA', '$ngaysinh','$ngaymat', '$quequan','$nguoilap','$matkhau','$hinh','','$dao')");
								$query = mysqli_query($connect,$sql);
								echo "Lập Mộ Thành Công";	
								 header("Location: http://localhost/NghiaTrangOnline/vanan-Phat.php");				
						}
							}
							mysqli_close($connect);
							
					
  							 ?>


                    </div>
                </div>

                <div class="clear"></div>
            </div>

        </div>

    </div>

    <div class="footer">
        <div class="wrap">
            <div class="bottom-content">
                <div class="col_1_of_footer span_1_of_footer">
                    <div class="footer-logo">
                        <!-- <a href="index.html"><img src="images/logo.png" alt=""/></a> -->
                    </div>
                    <div class="footer-border">


                    </div>
                </div>
                <div class="col_1_of_footer span_1_of_footer1">
                    <div class="col_1_of_footer span_1_of_footer">
                        <div class="sidebar-nav">

                        </div>
                    </div>
                    <div class="col_1_of_footer span_1_of_footer">

                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
        <div class="copy">
            <p class="copy">© 2020 Designed by <a href="">Vĩnh Hằng</a> </p>
        </div>
    </div>
    </div>









</body>

</html>

<style>
[type=radio] {
    position: absolute;
    opacity: 0;
    width: 0;
    height: 0;
}

/* IMAGE STYLES */
[type=radio]+img {
    cursor: pointer;
}

/* CHECKED STYLES */
[type=radio]:checked+img {
    outline: 2px solid green;

}

ul {
    list-style-type: none;
}

li {
    display: inline-block;
}

input[type="radio"] {
    display: none;
}

.imgcheck {
    border: 1px solid #fff;
    padding: 10px;
    display: block;
    position: relative;
    margin: 10px;
    cursor: pointer;
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}
.contact-form input[type="date"],
.contact-form textarea {
    padding: 8px;
    display: block;
    width: 98%;
    background: #fcfcfc;
    border: none;
    outline: none;
    color: #464646;
    font-size: 0.8125em;
    font-family: Arial, Helvetica, sans-serif;
    box-shadow: 0 0 5px #AAA;
    -webkit-box-shadow: 0 0 5px #AAA;
    -moz-box-shadow: 0 0 5px #AAA;
    -o-box-shadow: 0 0 5px #AAA;
    -webkit-appearance: none;
}
label::before {
    background-color: white;
    color: white;
    content: " ";
    display: block;
    border-radius: 50%;
    border: 1px solid grey;
    position: absolute;
    top: -5px;
    left: -5px;
    width: 25px;
    height: 25px;
    text-align: center;
    line-height: 28px;
    transition-duration: 0.4s;
    transform: scale(0);
}

label img {
    height: 100px;
    width: 100px;
    transition-duration: 0.2s;
    transform-origin: 50% 50%;
}

:checked+label {
    border-color: green;
}

:checked+label::before {
    content: "✓";
    background-color: green;
    transform: scale(1);

}

:checked+label img {
    transform: scale(0.9);
    box-shadow: 0 0 5px #333;
    z-index: -1;
}

.text-block {
    position: relative;
    bottom: 95px;
    right: 15px;
    background-color: none;
    color: sienna;
    text-align: center;
    padding-left: 80px;
    padding-right: 50px;
}

h6 {

    font-size: 11px;
}

.textyear {
    position: relative;
    bottom: 60px;

    left: 0px;
}

.contact-form input[type="password"],
.contact-form textarea {
    padding: 8px;
    display: block;
    width: 98%;
    background: #fcfcfc;
    border: none;
    outline: none;
    color: #464646;
    font-size: 0.8125em;
    font-family: Arial, Helvetica, sans-serif;
    box-shadow: 0 0 5px #AAA;
    -webkit-box-shadow: 0 0 5px #AAA;
    -moz-box-shadow: 0 0 5px #AAA;
    -o-box-shadow: 0 0 5px #AAA;
    -webkit-appearance: none;
}

.contact-form input[type="email"],
.contact-form textarea {
    padding: 8px;
    display: block;
    width: 98%;
    background: #fcfcfc;
    border: none;
    outline: none;
    color: #464646;
    font-size: 0.8125em;
    font-family: Arial, Helvetica, sans-serif;
    box-shadow: 0 0 5px #AAA;
    -webkit-box-shadow: 0 0 5px #AAA;
    -moz-box-shadow: 0 0 5px #AAA;
    -o-box-shadow: 0 0 5px #AAA;
    -webkit-appearance: none;
}

.batbuoc {
    color: red;

}

ul.breadcrumb {
    padding: 10px 16px;
    list-style: none;
    background-color: #eee;
}

ul.breadcrumb li {
    display: inline;
    font-size: 18px;
}

ul.breadcrumb li+li:before {
    padding: 8px;
    color: black;
    content: "/\00a0";
}

ul.breadcrumb li a {
    color: #0275d8;
    text-decoration: none;
}

ul.breadcrumb li a:hover {
    color: #01447e;
    text-decoration: underline;
}

.checkhinh {
    display: block;
}

	#progress {
		border: 1px solid #ccc;
		width: 300px;
		height: 20px;
		margin-top: 10px;
		text-align: center;
		position: relative;

	}

	#bar {
		background: #F39A3A;
		height: 20px;
		width: 0px;
	}

	#form-upload {
		padding: 10px;
		background: white;
		border-radius: 5px;
	}

	#percent {
		position: absolute;
		left: 50%;
		top: 0px;
	}
</style>