<!DOCTYPE HTML>
<html>

<head>
    <title>Khu Mộ Vạn An - Đức Phật</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script src="js/login.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/51b7f16ab3.js" crossorigin="anonymous"></script>
    <link rel="icon" href="images/icon.png">
</head>
<?php  
				include "ConnectDatabase.php"; 
                session_start(); 
       
				?>

<body>
    <div class="footer">
        <div class="wrap">
            <div class="header-top">
                <div class="header-left">
                    <div class="cssmenu" >
                        <ul>
                            <li><a href="trangchu.php"><span>Trang Chủ</span></a></li>
                            <?php 
                         if(!isset( $_SESSION["username"])){
                            
                          echo "  <li><a href='loginhome.php'><span>Đăng Nhập</span></a> </li>";
                           
                    }else{
                        echo "";
                        echo "
                       <form method='post' style='color:white;'>
                        Chào <a href=''> ".$_SESSION["username"]."</a>
                        <button name='logout' class='btn btn-default'>
                            <i class='fas fa-sign-out-alt'></i>
                        </button>
                    </form> 
                    ";
                     }
                      ?>
                        </ul>
                    </div>
                </div>
                <div class="clear"></div>
                <?php 
                        if(isset($_POST['logout'])){                          
                            session_unset();
                        }
                        
                        ?>

                <div class="clear"></div>
            </div>
        </div>
    </div>
    <div class="product-main">
        <div class="wrap">

            <div class="products-top">
                <div class="contact-form">
                    <form>
                        <span><label style="color: white;">Tìm Kiếm</label></span>
                        <span><input name="Search" type="text" class="textbox" placeholder="Tìm kiếm...." maxlength="30"
                                id="Search"></span>
                        <input type="submit" name="ok" value="Tìm Kiếm" />
                        <?php 
                             if (isset($_REQUEST['ok'])) 
                             {
                                 $search = addslashes($_GET['Search']);
                      
                                 if (empty($search)) {
                                     echo "Yêu Cầu Nhập Dữ Liệu Vào Ô Tìm Kiếm";
                                 } 
                                 else
                                 {
                                    $sql = "SELECT * FROM mo where TenNguoiKhuat like '%$search%' and Dao='Đức Phật'";
                                    $query = mysqli_query($connect,$sql);
                                    $result= mysqli_num_rows($query);
                                     
                                     if ($result > 0 && $search != "") 
                                     {
                                         while ($data = mysqli_fetch_assoc($query)) {
                                            $iDdb= $data['ID'];                  
                                            $namekhuat=$data['TenNguoiKhuat'];
                                            $nammat=$data['NgayThangNamMat'];
                                            $hinhmo=$data['Hinh'];
                                            echo "<br>";
                                            echo "<br>";
                                            echo "<br>";
                                            echo "<br>";
                                            echo "<br>";
                                            echo "<br>";
                                            echo "<a href='vanan-1-Phat.php?id=".$iDdb." class='text' > <h5 class='text-block searcha' id='text' > ".$namekhuat."</h5></a><br>";                                                  
                                         }
                                         mysqli_free_result($query);	  
                                     } 
                                     else {
                                         echo "Không Tìm Thấy Kết Quả!";
                                     }
                                 }
                             }
                            ?>
                    </form>
                </div>
                <marquee class="dategio">
                    <?php 
                 $sql = "SELECT * FROM mo ";
                 $query = mysqli_query($connect,$sql);
                 $result= mysqli_num_rows($query);
                $datetn = date('d/m/Y');
                $datehientai = date('d/m');
                $dao="Đức Phật";
                if($result>0 ){ 
                    while ( $data =mysqli_fetch_assoc($query )) { 
                        $nammat=date("d/m", strtotime($data['NgayThangNamMat']));
                        $namekhuat=$data['TenNguoiKhuat'];
                        $daon = $data['Dao'];
                   if( $datehientai  == $nammat && $dao == $daon){
                    echo "Hôm nay ngày  <i class='batbuoc'>" .$datetn. "</i>  là ngày giỗ của  <i class='batbuoc'><a href='vanan-1-Phat.php?id=$iDdb' > " .$namekhuat. "</a></i>   mau đến thắp nhan hoặc đọc kinh để cầu nguyện cho họ !";
                   } else{
                       echo "Người đi thong thả, thoát thế tục trần ai.Rồi lại sớm trở về dương thế...     ";
                   }
                
                    }
                }
                ?></marquee>

                <center>
                    <div class="grid_1_of_4 images_1_of_4 ">
                        <br>
                        <?php 
             //include "ConnectDatabase.php"; 
             //Hiển Thị Dữ Liệu
             $dao="Đức Phật";
             $sql = "SELECT * FROM mo ";
             $query = mysqli_query($connect,$sql);
             $result= mysqli_num_rows($query);
             $list=array("1"=>"1","2"=>"2","3"=>"3","4"=>"4","5"=>"5","6"=>"6","7"=>"7","8"=>"8","9"=>"9","10"=>"10");
          
			 if($result>0 ){ 
				while ( $data =mysqli_fetch_assoc($query )) {                 
                    $iDdb= $data['ID'];                  
					$namekhuat=$data['TenNguoiKhuat'];
                    $nammat=date("d/m/Y", strtotime($data['NgayThangNamMat']));
                    $hinhmo=$data['Hinh'];
                    $daon = $data['Dao'];
                    foreach ($list as $key => $value):
                        if($dao == $daon){
                        	
					if($iDdb == $value){ 
                        if($hinhmo == "5.jpg"){
                            echo("
                            <table>
                            <tbody>
                            <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                            printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                            if($nammat == "0000-00-00"){
                                echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                                }else{
                                    printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:120px;'> %s</h6></td>", $nammat);
                                }
                            echo("
                            </tbody>
                            </table>");
                        }else if($hinhmo == "6.jpg"){
                            echo("
                            <table>
                            <tbody>
                            <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                            printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                            if($nammat == "0000-00-00"){
                                echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                                }else{
                                    printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:95px;'> %s</h6></td>", $nammat);
                                }
                            echo("
                            </tbody>
                            </table>");
                        }else if($hinhmo == "7.jpg"){
                            echo("
                            <table>
                            <tbody>
                            <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                            printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                            if($nammat == "0000-00-00"){
                                echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                                }else{
                                    printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:107px;'> %s</h6></td>", $nammat);
                                }
                            echo("
                            </tbody>
                            </table>");
                        }else if($hinhmo == "3.jpg"){
                            echo("
                            <table>
                            <tbody>
                            <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                            printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                            if($nammat == "0000-00-00"){
                                echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                                }else{
                                    printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:95px;'> %s</h6></td>", $nammat);
                                }
                            echo("
                            </tbody>
                            </table>");
                        }else{
                            echo("
                            <table>
                            <tbody>
                            <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                            printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                            if($nammat == "0000-00-00"){
                            echo("<td><h6 class='textyear' id='nammat'> Không xác định</h6></td>");
                            }else{
                                printf("<td><h6 class='textyear' id='nammat'> %s</h6></td>", $nammat);
                            }
                            echo("
                            </tbody>
                            </table>");
                        }
                      
					
                    }
                }
				endforeach;
				 }					
				mysqli_free_result($query);	   				
                }	
               
                if($iDdb <= 10){ 			 
				for ($id=1;$id<=10;$id++) {					
					echo("<img src='images/	1.jpg' alt=''>");
                        echo("<br>");
                       
                    echo(" <form method='post'> <button type='submit'  name='checkloginss' class='btn btn-danger link'>Mộ Trống Lập Ngay</button></form>");
                    if(isset($_POST['checkloginss']))
                    {
                        if(!isset($_SESSION["username"])){
                            header("Location: http://localhost/NghiaTrangOnline/loginhome.php");
                        }else{
                            header("Location: http://localhost/NghiaTrangOnline/lapmo-Phat.php?id=$id&&username=".$_SESSION["username"]);
                        }
                    }
                   
					echo("<br>"); 
                    echo("<br>"); 
             
                }	
            }else{

            }	
        
			 ?>

                        <button onclick="topFunction()" id="myBtn" title="" class="fas fa-angle-up"></button>

                    </div>

                    <div class="grid_1_of_4 images_1_of_4 ">
                        <br>
                        <?php 
           //include "ConnectDatabase.php"; 
		   $sql = "SELECT * FROM mo ";
		   $query = mysqli_query($connect,$sql);
		   $result= mysqli_num_rows($query);
		   $list=array("11"=>"11","12"=>"12","13"=>"13","14"=>"14","15"=>"15","16"=>"16","17"=>"17","18"=>"18","19"=>"19","20"=>"20");
		   if($result>0 ){ 
			  while ( $data =mysqli_fetch_assoc($query )) {	
				  $iDdb= $data['ID'];
				  $namekhuat=$data['TenNguoiKhuat'];
                  $nammat=date("d/m/Y", strtotime($data['NgayThangNamMat']));
				  $hinhmo=$data['Hinh'];
				  foreach ($list as $key => $value):	
				  if($iDdb == $value){ 
                    if($hinhmo == "5.jpg"){
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                            echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                            }else{
                                printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:120px;'> %s</h6></td>", $nammat);
                            }
                        echo("
                        </tbody>
                        </table>");
                    }else if($hinhmo == "6.jpg"){
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                            echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                            }else{
                                printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:95px;'> %s</h6></td>", $nammat);
                            }
                        echo("
                        </tbody>
                        </table>");
                    }else if($hinhmo == "7.jpg"){
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                            echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                            }else{
                                printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:107px;'> %s</h6></td>", $nammat);
                            }
                        echo("
                        </tbody>
                        </table>");
                    }else if($hinhmo == "3.jpg"){
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                            echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                            }else{
                                printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:95px;'> %s</h6></td>", $nammat);
                            }
                        echo("
                        </tbody>
                        </table>");
                    }else{
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                        echo("<td><h6 class='textyear' id='nammat'> Không xác định</h6></td>");
                        }else{
                            printf("<td><h6 class='textyear' id='nammat'> %s</h6></td>", $nammat);
                        }
                        echo("
                        </tbody>
                        </table>");
                    }
                  
				  }
			  endforeach;
			   }					
			  mysqli_free_result($query);	   				
              }		
             // $data =mysqli_fetch_assoc($query );
              //$iDdb= $data['ID'];
              if($iDdb <20){ 
			  for ($id=11;$id<=20;$id++) {					
				  echo("<img src='images/	1.jpg' alt=''>");
					  echo("<br>");
                      echo(" <form method='post'> <button type='submit'  name='checkloginss' class='btn btn-danger link'>Mộ Trống Lập Ngay</button></form>");
                      if(isset($_POST['checkloginss']))
                      {
                          if(!isset($_SESSION["username"])){
                              header("Location: http://localhost/NghiaTrangOnline/loginhome.php");
                          }else{
                              header("Location: http://localhost/NghiaTrangOnline/lapmo-Phat.php?id=$id&&username=".$_SESSION["username"]);
                          }
                      }
                     
				  echo("<br>"); 
				  echo("<br>"); 
				  // echo("	<h6 class='textyear'> Số Mộ:".$id."</h6>"); 
              }	
            }else{


            }	
			?>

                    </div>

                    <div class="grid_1_of_4 images_1_of_4 ">
                        <br>
                        <?php 
			//include "ConnectDatabase.php"; 
			$sql = "SELECT * FROM mo ";
			$query = mysqli_query($connect,$sql);
			$result= mysqli_num_rows($query);
			$list=array("21"=>"21","22"=>"22","23"=>"23","24"=>"24","25"=>"25","26"=>"26","27"=>"27","28"=>"28","29"=>"29","30"=>"30");
			if($result>0 ){ 
			   while ( $data =mysqli_fetch_assoc($query )) {	
				   $iDdb= $data['ID'];
				   $namekhuat=$data['TenNguoiKhuat'];
                   $nammat=date("d/m/Y", strtotime($data['NgayThangNamMat']));
				   $hinhmo=$data['Hinh'];
				   foreach ($list as $key => $value):	
				   if($iDdb == $value){ 
                    if($hinhmo == "5.jpg"){
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                            echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                            }else{
                                printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:120px;'> %s</h6></td>", $nammat);
                            }
                        echo("
                        </tbody>
                        </table>");
                    }else if($hinhmo == "6.jpg"){
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                            echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                            }else{
                                printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:95px;'> %s</h6></td>", $nammat);
                            }
                        echo("
                        </tbody>
                        </table>");
                    }else if($hinhmo == "7.jpg"){
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                            echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                            }else{
                                printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:107px;'> %s</h6></td>", $nammat);
                            }
                        echo("
                        </tbody>
                        </table>");
                    }else if($hinhmo == "3.jpg"){
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                            echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                            }else{
                                printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:95px;'> %s</h6></td>", $nammat);
                            }
                        echo("
                        </tbody>
                        </table>");
                    }else{
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                        echo("<td><h6 class='textyear' id='nammat'> Không xác định</h6></td>");
                        }else{
                            printf("<td><h6 class='textyear' id='nammat'> %s</h6></td>", $nammat);
                        }
                        echo("
                        </tbody>
                        </table>");
                    }
                  
				   }
			   endforeach;
				}					
			   mysqli_free_result($query);	   				
			   }				 
			  if($iDdb < 30){ 			 
				for ($id=21;$id<=30;$id++) {					
					echo("<img src='images/	1.jpg' alt=''>");
						echo("<br>");
                        echo(" <form method='post'> <button type='submit'  name='checkloginss' class='btn btn-danger link'>Mộ Trống Lập Ngay</button></form>");
                        if(isset($_POST['checkloginss']))
                        {
                            if(!isset($_SESSION["username"])){
                                header("Location: http://localhost/NghiaTrangOnline/loginhome.php");
                            }else{
                                header("Location: http://localhost/NghiaTrangOnline/lapmo-Phat.php?id=$id&&username=".$_SESSION["username"]);
                            }
                        }
                       
					echo("<br>"); 
					echo("<br>"); 
					// echo("	<h6 class='textyear'> Số Mộ:".$id."</h6>"); 
                }	
            }else{

                
            }	
			   
			?>

                    </div>
                    <div class="grid_1_of_4 images_1_of_4 ">
                        <br>
                        <?php 
                    
         //include "ConnectDatabase.php"; 
		 $sql = "SELECT * FROM mo ";
		 $query = mysqli_query($connect,$sql);
		 $result= mysqli_num_rows($query);
		 $list=array("31"=>"31","32"=>"32","33"=>"33","34"=>"34","35"=>"35","36"=>"36","37"=>"37","38"=>"38","39"=>"39","40"=>"40");
		 if($result>0 ){ 
			while ( $data =mysqli_fetch_assoc($query )) {	
				$iDdb= $data['ID'];
				$namekhuat=$data['TenNguoiKhuat'];
                $nammat=date("d/m/Y", strtotime($data['NgayThangNamMat']));
				$hinhmo=$data['Hinh'];
				foreach ($list as $key => $value):	
				if($iDdb == $value){ 
                    if($hinhmo == "5.jpg"){
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                            echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                            }else{
                                printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:120px;'> %s</h6></td>", $nammat);
                            }
                        echo("
                        </tbody>
                        </table>");
                    }else if($hinhmo == "6.jpg"){
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                            echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                            }else{
                                printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:95px;'> %s</h6></td>", $nammat);
                            }
                        echo("
                        </tbody>
                        </table>");
                    }else if($hinhmo == "7.jpg"){
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                            echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                            }else{
                                printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:107px;'> %s</h6></td>", $nammat);
                            }
                        echo("
                        </tbody>
                        </table>");
                    }else if($hinhmo == "3.jpg"){
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Phat.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                            echo("<td><h6 class='textyear' id='nammat'> ???</h6></td>");
                            }else{
                                printf("<td><h6 class='textyear' id='nammat' style='color:white; bottom:95px;'> %s</h6></td>", $nammat);
                            }
                        echo("
                        </tbody>
                        </table>");
                    }else{
                        echo("
                        <table>
                        <tbody>
                        <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class='hinhmo'></tr>"); 	
                        printf("<tr><a href='vanan-1-Chua.php?id=%s' class='text' > <h5 class='text-block' id='text' > %s</h5></a><br></tr>",$iDdb,$namekhuat);
                        if($nammat == "0000-00-00"){
                        echo("<td><h6 class='textyear' id='nammat'> Không xác định</h6></td>");
                        }else{
                            printf("<td><h6 class='textyear' id='nammat'> %s</h6></td>", $nammat);
                        }
                        echo("
                        </tbody>
                        </table>");
                    }
                  
				}
			endforeach;
			 }					
			mysqli_free_result($query);	   				
			}				 
			if($iDdb < 40){ 			 
				for ($id=31;$id<=40;$id++) {					
					echo("<img src='images/	1.jpg' alt=''>");
						echo("<br>");
                        echo(" <form method='post'> <button type='submit'  name='checkloginss' class='btn btn-danger link'>Mộ Trống Lập Ngay</button></form>");
                        if(isset($_POST['checkloginss']))
                        {
                            if(!isset($_SESSION["username"])){
                                header("Location: http://localhost/NghiaTrangOnline/loginhome.php");
                            }else{
                                header("Location: http://localhost/NghiaTrangOnline/lapmo-Phat.php?id=$id&&username=".$_SESSION["username"]);
                            }
                        }
                       
					echo("<br>"); 
					echo("<br>"); 
					// echo("	<h6 class='textyear'> Số Mộ:".$id."</h6>"); 
                }	
            }else{

                
            }		

			?>

                    </div>

                </center>
                <div class="clear"></div>
            </div>



        </div>
    </div>
    </div>
    <div class="footer">
        <div class="wrap">
            <div class="bottom-content">
                <div class="col_1_of_footer span_1_of_footer">
                    <div class="footer-logo">

                    </div>
                    <div class="footer-border">


                    </div>
                </div>
                <div class="col_1_of_footer span_1_of_footer1">
                    <div class="col_1_of_footer span_1_of_footer">
                        <div class="sidebar-nav">

                        </div>
                    </div>
                    <div class="col_1_of_footer span_1_of_footer">

                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
        <div class="copy">
            <p class="copy">© 2020 Designed by <a href="">Vĩnh Hằng</a> </p>
        </div>
    </div>
    </div>
</body>

</html>

<style>
.text-block {
    position: relative;
    bottom: 95px;
    right: 15px;
    background-color: none;
    color: sienna;
    text-align: center;
    padding-left: 80px;
    padding-right: 50px;
    word-wrap: break-word;
}

h6 {

    font-size: 11px;
}

.textyear {
    position: relative;
    bottom: 90px;
    left: 0px;
}

#myBtn {
    display: none;
    position: fixed;
    bottom: 20px;
    right: 30px;
    z-index: 99;
    font-size: 18px;
    border: none;
    outline: none;
    background-color: #0674ec;
    color: white;
    cursor: pointer;
    padding: 15px;
    border-radius: 50px;
}

#myBtn:hover {
    background-color: #0674ec;
    opacity: 0.9;
}

ul.breadcrumb {
    padding: 10px 16px;
    list-style: none;
    background-color: #eee;
}

ul.breadcrumb li {
    display: inline;
    font-size: 18px;
}

ul.breadcrumb li+li:before {
    padding: 8px;
    color: black;
    content: "/\00a0";
}

ul.breadcrumb li a {
    color: #0275d8;
    text-decoration: none;
}

ul.breadcrumb li a:hover {
    color: #01447e;
    text-decoration: underline;
}

.contact-form input[type="text"],
.contact-form textarea {
    padding: 8px;
    display: block;
    width: 98%;
    background: #fcfcfc;
    border: none;
    outline: none;
    color: #464646;
    font-size: 0.8125em;
    font-family: Arial, Helvetica, sans-serif;
    box-shadow: 0 0 5px #AAA;
    -webkit-box-shadow: 0 0 5px #AAA;
    -moz-box-shadow: 0 0 5px #AAA;
    -o-box-shadow: 0 0 5px #AAA;
    -webkit-appearance: none;
}

body {
    background-image: url('images/nenphat.jpg');
    background-size: 2500px 3000px;
}

.searcha {
    color: sienna;
}

.dategio {
    color: white;
    position: relative;
    bottom: -10px;
    padding-left: 100px;
    text-shadow: 0 0 2px black;
    background-position: center center;
    text-align: center;
    text-transform: uppercase;
    display: inline-block;
}

.batbuoc {
    color: red;
    text-shadow: 0 0 5px white;
    font-weight: bold;
}
</style>
<script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {
    scrollFunction()
};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
    } else {
        mybutton.style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>
<!-- <script>
var hinhmo = document.getElementById("hinhmo").src;
var text = document.getElementById("text");
var nammat = document.getElementById("nammat");
var srchinh = "http://localhost/NghiaTrangOnline/images/4.jpg";
var srchinh5 = "http://localhost/NghiaTrangOnline/images/3.jpg";
var srchinh1 = "http://localhost/NghiaTrangOnline/images/5.jpg";
var srchinh2 = "http://localhost/NghiaTrangOnline/images/6.jpg";
var srchinh3 = "http://localhost/NghiaTrangOnline/images/7.jpg";
var srchinh4 = "http://localhost/NghiaTrangOnline/images/8.jpg";
if (hinhmo == srchinh) {
    nammat.style.color = "white";
}
if (hinhmo == srchinh1) {
    nammat.style.bottom = "120px";
    nammat.style.color = "white";
}
if (hinhmo == srchinh2) {
    nammat.style.color = "white";
}
if (hinhmo == srchinh3) {
    nammat.style.color = "white";
    nammat.style.bottom = "120px";
}
if (hinhmo == srchinh4) {
    nammat.style.color = "white";
    text.style.bottom = "80px";
}
if (hinhmo == srchinh5) {
    nammat.style.color = "white";
}
</script> -->