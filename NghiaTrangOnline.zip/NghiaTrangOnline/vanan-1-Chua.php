<!DOCTYPE HTML>
<html>

<head>
    <?php  
 include "ConnectDatabase.php"; 
$id=$_GET['id'];
$sql = "SELECT * FROM mo  WHERE ID='$id'";
			 $query = mysqli_query($connect,$sql);
			 if($query){		
			 while ( $data =mysqli_fetch_array($query) ) {
?>
    <title>Mộ Online <?php echo $data[1]. "-". $data[2];  ?></title>
    <?php }}?>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/demo.css" rel="stylesheet" type="text/css" media="all" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script src="js/login.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
    <script src="https://kit.fontawesome.com/51b7f16ab3.js" crossorigin="anonymous"></script>
    <link rel="icon" href="images/iconchua.png">
</head>

<body style="background-image: url('images/nentrang.jpg');">
    <div class="footer">
        <div class="wrap">
            <div class="header-top">
                <div class="header-left">

                    <div class="cssmenu">
                        <ul>
                            <li><a href="trangchu.php"><span>Trang Chủ</span></a></li>
                            <!-- <li  class="active"><a href="khumo.php"><span>Khu Mộ</span></a></li> -->
                            <!-- <li><a href="services.html"><span>Quy Định</span></a></li> -->
                            <!-- <li class="has-sub"><a href="work.html"><span>My Work</span></a></li> -->
                            <!-- <li class="last"><a href="contact.html"><span>Liên Hệ</span></a></li> -->
                            <div class="clear"></div>
                        </ul>
                    </div>
                </div>

                <div class="clear"></div>
            </div>
        </div>
    </div>
    <?php  
 //include "ConnectDatabase.php"; 
$id=$_GET['id'];
$sql = "SELECT * FROM mo  WHERE ID='$id'";
			 $query = mysqli_query($connect,$sql);
			 if($query){		
			 while ( $data =mysqli_fetch_array($query) ) {
?>
    <div class="wrap">
        <br />
        <ul class="breadcrumb">
            <li><a href="trangchu.php">Trang Chủ</a></li>
            <li><a href="partion.php">Cổng Mộ Vạn An</a> </li>
            <li><a href="vanan-Chua.php">Khu Mộ Vạn An - Thiên Chúa</a> </li>
            <li>Phần Mộ <?php echo$data[1]; ?> - <?php echo$data[2]; ?></li>
            <input type="hidden" value="<?php echo $data[0]; ?>" id="idngmat" name="idngmat">

        </ul>
        <div class="header-top" id="mool_load_chinh">
            <div class="moll">
                <img src="images/biabaivi.png" alt="">
                <img src="<?php echo $data[10]; ?>" alt="" class="moll_hinh" id="hinhbia">
                <p class="moll_ten_thanh" id="tenthanh"> <br> <?php
                $cacthanhnam= array('Phêrô', 'Anrê', 'Gioan Baotixita', 'Gioan', 'Phaolô', 'Giuđa', 'Philipphê', 'MátThêu', 'Giacôbê',
                 'Tôma', 'Mátthia', 'Nathanaen');
                 foreach($cacthanhnam as $key => $value):
                    if($data[1] == $value){
                        echo "Ông : ".$data[1] ;
                    }else{
                        echo " ";
                    }
                 endforeach;
                 $cacthanhnu= array('Anna', 'Maria', 'Têrêsa', 'Lucia', 'INê', 'FausTiNa', 'MôNiCa', 'Maria Mađalêna',
                 'Catarina De Siena');
                 foreach($cacthanhnu as $key => $value):
                    if($data[1] == $value){
                        echo "Bà : ".$data[1] ;
                    }else{ 
                        echo " ";
                    }
                 endforeach;
                //  echo $data[1];
                 ?></p>
                <input type="hidden" value="<?php echo $data[1]; ?>" id="tenthanhan" name="tenthanhan">
                <p class="moll_ten_khuat" id="tenngmat"><br><?php echo $data[2];?></p>
                <br><br>
                <p class="moll_nam" id="nammat"><?php 
                 $ngaysinh = date("d/m/Y", strtotime($data[4])); 
                 $ngaymat = date("d/m/Y", strtotime($data[5])); 
                 if($data[4] != "0000-00-00" && $data[5] != "0000-00-00"){
                    echo $ngaysinh. " - " .$ngaymat ;
                    }else if($data[4]  == "0000-00-00" && $data[5] == "0000-00-00") {
                    echo " ???? - ???? ";
                    }else if($data[4] == "0000-00-00"){
                    echo " ???? -  ".$ngaymat;
                    }else  if($data[5]== "0000-00-00"){
                  echo $ngaysinh." - ???? ";
                    }
                    
                    ?></p>
                <br>
                <p class="moll_quequan" id="quequan">Quê Quán: <?php echo $data[6];?></p>
                <br>
                <p class="moll_huongtho" id="huongtho"><?php  
                 $nammat1= date("Y", strtotime($data[5]));
                  $namsinh1 =date("Y", strtotime($data[4])); 
                    $tongtuoi= $nammat1 - $namsinh1; 
                    if($data[4] != "0000-00-00" && $data[5] != "0000-00-00"){                  
                        if($tongtuoi <= 60){
                            echo "Hưởng Dương: " .$tongtuoi;
                         }else if($tongtuoi >= 80){
                           echo " Thượng Thọ: " .$tongtuoi;
                            }else {
                           echo " Hưởng Thọ: " .$tongtuoi;
                          } 
                     }else if($data[4]  == "0000-00-00" && $data[5] == "0000-00-00") {
                            echo "?";
                     }else if($data[4] == "0000-00-00"){
                            echo "?";
                     }else  if($data[5]== "0000-00-00"){
                            echo "?";
                     }
                    ?> tuổi </p>
                <br>
                <p class="moll_lapmo" id="nglapmo"><?php echo $data[7];?> lập mộ</p>
                <button onclick="topFunction()" id="myBtn" title="" class="fas fa-angle-up"></button>

            </div>
            <div id="">
                <table class="hinhvieng">
                    <tbody>
                        <tr>
                            <th id="qua"></th>
                            <th id="linhthieng"></th>
                            <th id="hoa"></th>
                        </tr>



                    </tbody>

                </table>

            </div>

            <div class="vieng">

                <marquee class="load">
                    <i id="mool_load_cn"></i>
                    <div class="clear"></div>

                </marquee>
                <i id="amthanh" class="amthanh"></i>
                <marquee class="caunguyen">
                    <i id="loicau_nguyen"></i>
                </marquee>
                <p cn="4" class="dockinh vieng_le" id="dockinh"><img src="images/book1243.gif" width="40" height="40">
                    Đọc Kinh
                </p>

                <p class="text-block">

                    <b cn="1" class="vieng_le">Thắp Nhang</b>
                    <b cn="2" class="vieng_le">Đặt Lễ</b>
                    <b cn="3" class="vieng_le">Đặt Hoa</b>

                    <a href="login.php?id=<?php echo $data[0];?>" class="vieng_le">Sửa Mộ</a>




                </p>

                <?php }
         }?>
                <br>


            </div>
            <h1 class="textmo">Các Phần Mộ Lân Cận Thuộc <a href="vanan-Chua.php" class="linkmo"> Khu Mộ Vạn An - Thiên
                    Chúa</a></h1>
            <div class=" hinhmo ">
                <br>
                <div class="clear"></div>
                <?php
                 $dao="Thiên Chúa";
              $sql = "SELECT * FROM mo WHERE Dao='$dao' LIMIT 6";
                $query = mysqli_query($connect,$sql);
                $result= mysqli_num_rows($query);
                
			 if($result>0 ){ 
				while ( $data =mysqli_fetch_assoc($query )) {                 
                    $iDdb= $data['ID'];                  
					$namekhuat=$data['TenNguoiKhuat'];
					$nammat=date("d/m/Y", strtotime($data['NgayThangNamMat']));
                    $hinhmo=$data['Hinh'];
                    $daon = $data['Dao'];   
                    $id=$_GET['id'];
                   
                    if($iDdb != $id && $daon == $dao){
                        if($hinhmo == "4.jpg"){
                            echo("    <table class='showmo'>
                            <tbody>
                                <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class=''>
                            </tr>
                            <tr><a href='vanan-1-Chua.php?id=$iDdb'>
                                    <h5 class='text-name' id='text'>$namekhuat</h5>
                                </a><br></tr>
                            <td>
                                <h6 class='text-nam' id='nammat'style='color:white;'>$nammat</h6>
                            </td>
                            </tbody>
                            </table>");
            

                        }else if($hinhmo =="8.jpg"){
                            echo("    <table class='showmo'>
                            <tbody>
                                <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class=''>
                            </tr>
                            <tr><a href='vanan-1-Chua.php?id=$iDdb'>
                                    <h5 class='text-name' id='text'>$namekhuat</h5>
                                </a><br></tr>
                            <td>
                                <h6 class='text-nam' id='nammat' style='color:white;'>$nammat</h6>
                            </td>
                            </tbody>
                            </table>");
                        }else{
                            echo("    <table class='showmo'>
                            <tbody>
                                <tr><img src='images/$hinhmo' alt='' width='150' height='200' id='hinhmo' class=''>
                            </tr>
                            <tr><a href='vanan-1-Chua.php?id=$iDdb'>
                                    <h5 class='text-name' id='text'>$namekhuat</h5>
                                </a><br></tr>
                            <td>
                                <h6 class='text-nam' id='nammat' >$nammat</h6>
                            </td>
                            </tbody>
                            </table>");
                        }
           

                }
                    }
                }
                ?>


            </div>
        </div>

        <br />

    </div>
    <div class="clear"> </div>
    <div class="footer">
        <div class="wrap">
            <div class="bottom-content">
                <div class="col_1_of_footer span_1_of_footer">
                    <div class="footer-logo">

                    </div>
                    <div class="footer-border">








                    </div>
                </div>
                <div class="col_1_of_footer span_1_of_footer1">
                    <div class="col_1_of_footer span_1_of_footer">
                        <div class="sidebar-nav">

                        </div>
                    </div>
                    <div class="col_1_of_footer span_1_of_footer">

                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
        <div class="copy">
            <p class="copy">© 2020 Designed by <a href="">Vĩnh Hằng</a> </p>
        </div>
    </div>
    </div>

</html>



<!-- Style BaiVi -->
<style>
.moll {
    width: 300px;
    height: 390px;
    background-position: center center;
    margin: auto;
    padding-top: 96px;
    overflow: hidden;
}

.moll_hinh {
    text-align: center;
    width: 30%;
    left: 106px;
    position: relative;
    bottom: 350px;
    border-radius: 50%;
}

.moll_ten {
    text-align: center;
    width: 60%;
    margin: auto;
    height: 165px;
    overflow: hidden;

}

.moll_ten_khuat {
    color: white;
    font-size: 18px;
    text-transform: uppercase;
    bottom: 370px;
    text-shadow: 0 0 3px yellowgreen;
    position: relative;
    text-align: center;
    word-wrap: break-word;
}


.moll_ten_thanh {
    color: white;
    font-size: 18px;
    text-transform: uppercase;
    bottom: 350px;
    text-shadow: 0 0 3px yellowgreen;
    position: relative;
    text-align: center;
    word-wrap: break-word;
}

.moll_nam {
    color: white;
    font-size: 18px;
    text-align: center;
    bottom: 400px;
    position: relative;
}

.moll_quequan {
    color: white;
    font-size: 18px;
    text-align: center;
    bottom: 420px;
    position: relative;
}

.moll_huongtho {
    color: white;
    font-size: 18px;
    text-align: center;
    bottom: 440px;
    position: relative;
}

.moll_lapmo {
    color: white;
    font-size: 12px;
    text-align: center;
    bottom: 410px;
    position: relative;
    font-style: italic;
    opacity: 0.5;
}

b {
    font-weight: bold;

}

p {
    font-weight: bold;
}

.textmo {
    display: block;
    clear: bold;
    background: rgba(0, 0, 0, 0.7);
    text-transform: uppercase;
    color: #d96c00;
    padding: 10px;
    margin-top: 5px;
    margin-bottom: 5px;
}

.lapmo {
    background: url(../images/list-arrow.gif) no-repeat 100% 8px;
    display: inline-block;
    line-height: 19px;
    font-size: 0.89em;

    font-style: normal;
    text-decoration: underline;
    color: #F58972;
    font-family: 'Droid Sans', sans-serif;
    text-transform: uppercase;
}

.lapmo:hover {
    text-decoration: none;
    color: #333;
}

.mollmo {

    background-position: center center;
    margin: auto;

    overflow: hidden;
}

.text-block {
    position: relative;
    bottom: 10px;
    right: 20px;
    height: 30px;
    background-color: palegoldenrod;
    opacity: 0.9;
    width: 390px;
    padding-left: 10px;
    padding-right: 10px;
    text-align: center;
}

.text-name {
    color: sienna;
    text-align: center;
    bottom: -120px;
    position: relative;
    left: -200px;
    font-size: 13px;
}

.text-nam {
    color: black;
    text-align: center;
    bottom: -160px;
    position: relative;
    left: -150px;
    font-size: 13px;
}

.vieng {
    width: 400px;
    height: 290px;
    background-position: center center;
    margin: auto;
    padding-top: 120px;
    overflow: hidden;

}

.vieng_le {
    padding-right: 10px;
    padding-left: 10px;
    text-align: center;
    position: relative;
    bottom: -7px;
    left: 10px;
    right: 10px;
    color: #f44336;
}

.vieng_le:hover {
    text-decoration: none;
    color: hotpink;
}

.load {
    width: 400px;
    height: 20px;
    position: relative;
    color: red;

    margin: 10px;
}


.huong {
    text-align: center;
    position: inherit;

}

.hinhvieng {

    background-position: center center;
    margin: auto;
    padding-top: 96px;
    overflow: hidden;
}

.hinhmo {
    column-count: 4;
    column-width: 100px;
    column-span: all;
    column-gap: 40px;
    width: 350px;
    height: 350px;
    background-position: center center;


    overflow: hidden;
    column-rule-width: 1px;
}


.linkmo {
    color: #f44336;
    background-position: center center;
    padding-left: 10px;
    padding-bottom: 10px;
    overflow: hidden;
    position: relative;
}

th {
    display: table-cell;
    vertical-align: inherit;
    font-weight: bold;
    text-align: initial center;
}

body {
    background-image: url("images/nen.jpg");
    background: 'images/nen.jpg';

}

#myBtn {
    display: none;
    position: fixed;
    bottom: 20px;
    right: 30px;
    z-index: 99;
    font-size: 18px;
    border: none;
    outline: none;
    background-color: #0674ec;
    color: white;
    cursor: pointer;
    padding: 15px;
    border-radius: 50px;
}

#myBtn:hover {
    background-color: #0674ec;
    opacity: 0.9;
}

ul.breadcrumb {
    padding: 10px 16px;
    list-style: none;
    background-color: #eee;
}

ul.breadcrumb li {
    display: inline;
    font-size: 18px;
}

ul.breadcrumb li+li:before {
    padding: 8px;
    color: black;
    content: "/\00a0";
}

ul.breadcrumb li a {
    color: #0275d8;
    text-decoration: none;
}

ul.breadcrumb li a:hover {
    color: #01447e;
    text-decoration: underline;
}

.dockinh {
    color: white;
    position: relative;
    background-position: center center;
    bottom: 30px;
    padding-left: 270px;

}

.amthanh {
    position: relative;
    bottom: 120px;
    padding-left: 100px;
}

.caunguyen {
    color: white;
    position: relative;
    bottom: 140px;
    padding-left: 100px;
}

.batbuoc {
    color: red;

}
</style>
<!---->
<script>
var cacthanhnam = ['Phêrô', 'Anrê', 'Gioan Baotixita', 'Gioan', 'Phaolô', 'Giuđa', 'Philipphê', 'MátThêu', 'Giacôbê',
    'Tôma', 'Mátthia', 'Nathanaen'
];
var cacthanhnu = ['Anna', 'Maria', 'Têrêsa', 'Lucia', 'INê', 'FausTiNa', 'MôNiCa', 'Maria Mađalêna',
    'Catarina De Siena'
];
var tenthanh = document.getElementById("tenthanh");
var tenthanhbia = document.getElementById("tenthanhan").value;
var tenmo = document.getElementById("tenngmat");
var nglapmo = document.getElementById("nglapmo");
if (tenmo > 30) {
    nglapmo.style.bottom = "350";
}

var nammat = document.getElementById("nammat");
var quequan = document.getElementById("quequan");
var hinhbia = document.getElementById("hinhbia").src;
var huongtho = document.getElementById("huongtho");
var idngmat = document.getElementById("idngmat").value;
if (tenmo > 30) {
    nglapmo.style.bottom = "350";
}
cacthanhnam.forEach(function(item, index, array) {
    if (tenthanhbia == item) {
        tenthanh.style.textShadow = "0 0 3px red";

    }
});

cacthanhnu.forEach(function(item, index, array) {
    if (tenthanhbia == item) {
        tenthanh.style.textShadow = "0 0 3px  #ff4da6";
    }
});
var linkla = "http://localhost/NghiaTrangOnline/vanan-1-Chua.php?id=" + idngmat;
var linkse = "http://localhost/NghiaTrangOnline/vanan-1-Chua.php?id=" + idngmat + "%20class=";
if (hinhbia == linkla || hinhbia == linkse) {
    tenthanh.style.bottom = "230px";
    tenmo.style.bottom = "250px";
    quequan.style.bottom = "320px";
    nammat.style.bottom = "250px";
    huongtho.style.bottom = "290px";
    nglapmo.style.bottom = "290px";
} else {
    tenmo.style.bottom = "360px";
    quequan.style.bottom = "435px";
    nammat.style.bottom = "375px";
    huongtho.style.bottom = "434px";
    nglapmo.style.bottom = "410px";
}
</script>
<script>
$("#mool_load_chinh b").click(function() {
    if ($(this).attr("cn") == "1") {
        var thapnhan = setTimeout(() => {
            document.getElementById("mool_load_cn").innerHTML =
                "Xin thắp nén hương trầm - ấm lòng người dưới mộ !";


        }, 1500);
        document.getElementById("linhthieng").innerHTML =
            "<img src='images/huong.png' alt='' class='huongqua'>";

        function clearAlert() {

            clearTimeout(thapnhan);
        }


    } else if ($(this).attr("cn") == "2") {
        var datle = setTimeout(() => {
            document.getElementById("mool_load_cn").innerHTML =
                "Xin thành tâm dâng lễ, thành tâm kính viến !";


        }, 1500);
        document.getElementById("qua").innerHTML = "<img src='images/qua.png' alt='' class='huongqua'>";

        function clearAlert() {
            clearTimeout(datle);

        }
    } else if ($(this).attr("cn") == "3") {

        var danghoa = setTimeout(() => {
            document.getElementById("mool_load_cn").innerHTML =
                "Xin dâng những đóa hoa, thành tâm cầu linh hồn an nghỉ !";

        }, 1500);
        document.getElementById("hoa").innerHTML = "<img src='images/hoa1.png' alt='' class='huongqua'>";

        function clearAlert() {
            clearTimeout(danghoa);
        }

    } else if ($(this).attr("cn") == "4") {
        hien_cn_sua();
    }
    $(this).remove();
});

$("#dockinh").click(function() {
    if ($(this).attr("cn") == "4") {
        var tenthanh = document.getElementById("tenthanhan").value;
        var loicau = document.getElementById("loicau_nguyen").innerHTML =
            "Cầu cho linh hồn <i class='batbuoc'>" + tenthanh +
            "</i>  được lên chốn nghỉ ngơi. Hằng xem thấy mặt Đức Chúa Trời sáng láng vui vẻ vô cùng. Amen";
        var amthanh = document.getElementById("amthanh").innerHTML =
            " <audio  autoplay class='atui' > <source src = 'audio/kinhChua.mp3' type = 'audio/ogg' > </audio>";


    }
});
</script>

<script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {
    scrollFunction()
};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
    } else {
        mybutton.style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>