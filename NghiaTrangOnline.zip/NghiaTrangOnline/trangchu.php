<!DOCTYPE HTML>
<html>

<head>
    <title>Nghĩa Trang Online</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
    <script src="js/login.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Azuki' rel='stylesheet' type='text/css'>
    <!-- the jScrollPane script -->
    <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
    <!-- the jScrollPane script -->
    <script type="text/javascript" src="js/jquery.mousewheel.js"></script>
    <script type="text/javascript" src="js/jquery.contentcarousel.js"></script>
    <script src="https://kit.fontawesome.com/51b7f16ab3.js" crossorigin="anonymous"></script>
    <link rel="icon" href="images/icon.png">
    <script src="https://lichngaytot.com/Content/Js/Libs/jquery-ui.min.js"></script>
    <script src="https://lichngaytot.com/Content/Js/Widget/widgetlichngay.js"></script>

</head>

<body>

    <div class="footer">
        <div class="wrap">
            <div class="header-top">
                <div class="header-left">
                    <div class="cssmenu">
                        <ul>
                            <li><a href="trangchu.php"><span>Trang Chủ</span></a></li>
                            <?php 
                           include "ConnectDatabase.php"; 
                              session_start(); 
                           
                         if(!isset( $_SESSION["username"])){
                            
                          echo "  <li><a href='loginhome.php'><span>Đăng Nhập</span></a> </li>";
                           
                    }else{
                        echo "";
                        echo "
                       <form method='post' style='color:white;'>
                        Chào <a href=''> ".$_SESSION["username"]."</a>
                        <button name='logout' class='btn btn-default'>
                            <i class='fas fa-sign-out-alt'></i>
                        </button>
                    </form> 
                    ";
                    
                     }
                      ?>
                            <?php 
                        if(isset($_POST['logout'])){                          
                            session_unset();
                            
                        }
                        
                        ?>
                        </ul>
                    </div>
                </div>

                <div class="clear"></div>
            </div>
            <div class="clear"></div>

        </div>
    </div>
    <div class="main">
        <div class="wrap">
            <div class="about-top">
                <div class="header-right ">
                    <script type="text/javascript">
                    document.write(
                        '<div class="tao-lich-left widgetlich-lvsicsoft" id="widgetlich-lvsicsoft" style="width:auto;background-color: black;" data-urlimagen="" data-colorbordern="#9d9595" data-coloramn="#7f7f7f" data-colorduongn="#000000"></div>'
                    );
                    getWidgetLichNgay("widgetlich-lvsicsoft");
                    </script>
                    <br>
                    <div class="clear"></div>

                    <!-- <script id="_wauggq">var _wau = _wau || []; _wau.push(["small", "2u0h5hb3f5", "ggq"]);</script><script async src="//waust.at/s.js"></script> -->
                </div>

                <center>
                    <div class="col  span_1_of_about ">
                        <h3>Khu Mộ</h3>

                        <button onclick="topFunction()" id="myBtn" title="" class="fas fa-angle-up"></button>


                        <div id="snackbar" class=""> <i> <span id="molsnol" title=""> 100 </span> Người Viếng Mộ</i>
                        </div>
                </center>

                <div class="rsidebar">
                    <div class="span_2_of_3 ">
                        <?php  
			
				$sql = "SELECT COUNT(*) FROM movinhhang";
				$query = mysqli_query($connect,$sql);
				$result= mysqli_num_rows($query);		  				 
					
				$tongmo=80;
				
				if($query){
					while ( $data =mysqli_fetch_array($query) ) {
							$a = $data[0];
							
                            }
                            }
                            $tongcon=$tongmo - $a;
				?>
                        <img src="images/khu.jpg" alt="" width="500" />
                        <p class="text-block">
                            <?php if($tongcon < $tongmo){ echo "Còn $tongcon mộ chưa lập";  }else if($tongcon == $a){echo "Đầy $tongmo/$tongmo";} else{ echo "Còn $tongmo chưa lập mộ";}?>
                        </p>
                        <a href="partion-vinhhang.php" class="container">
                            <b class="col_1_of_2  text1 fontdemo">Khu Mộ Vĩnh Hằng</b>
                        </a>
                    </div>
                    <div class="span_2_of_3 ">
                        <?php  
				
				$sql = "SELECT COUNT(*) FROM mo";
				$query = mysqli_query($connect,$sql);
				$result= mysqli_num_rows($query);		  				 
					
				$tongmo=80;
				
				if($query){
					while ( $data =mysqli_fetch_array($query) ) {
							$a = $data[0];
							
                            }
                            }
                            $tongcon=$tongmo - $a;
				?>
                        <img src="images/khu.jpg" alt="" width="500">
                        <p class="text-block">
                            <?php if($tongcon < $tongmo){ echo "Còn $tongcon mộ chưa lập";  }else if($tongcon == $a){echo "Đầy $tongmo/$tongmo";} else{ echo "Còn $tongmo chưa lập mộ";}?>
                        </p>
                        <a href="partion.php" class="container">
                            <b class="col_1_of_2 text1 fontdemo">Khu Mộ Vạn An</b>
                            <style>
                            @font-face {
                                font-family: azuki;
                                src: url('fonts/UTM Azuki.ttf')
                            }

                            .text6 {
                                font-family: azuki;
                            }
                            </style>
                        </a>
                    </div>
                    <div class="span_2_of_3">
                        <?php  
			
            $sql = "SELECT COUNT(*) FROM mothienthai";
            $query = mysqli_query($connect,$sql);
            $result= mysqli_num_rows($query);		  				 
                
            $tongmo=80;
            
            if($query){
                while ( $data =mysqli_fetch_array($query) ) {
                        $a = $data[0];
                        
                        }
                        }
                        $tongcon=$tongmo - $a;
            ?>
                        <img src="images/khu.jpg" alt="" width="500">
                        <p class="text-block">
                            <?php if($tongcon < $tongmo){ echo "Còn $tongcon mộ chưa lập";  }else if($tongcon == $a){echo "Đầy $tongmo/$tongmo";} else{ echo "Còn $tongmo chưa lập mộ";}?>
                        </p>
                        <a href="partion-thienthai.php" class="container">
                            <b class="col_1_of_2 text1 fontdemo">Khu Mộ Thiên Thai</b>
                        </a>
                    </div>
                    <div class="span_2_of_3">
                        <img src="images/khu.jpg" alt="" width="500">
                        <p class="text-block">Còn 20 mộ chưa lập</p>
                        <a href="" class="container">
                            <b class="col_1_of_2 text1 fontdemo">Khu Mộ Thú Cưng</b>
                        </a>
                    </div>
                </div>

                <div class="rsidebar">
                    <div class="span_2_of_3">
                        <?php  
			
            $sql = "SELECT COUNT(*) FROM mothieunhi";
            $query = mysqli_query($connect,$sql);
            $result= mysqli_num_rows($query);		  				 
                
            $tongmo=80;
            
            if($query){
                while ( $data =mysqli_fetch_array($query) ) {
                        $a = $data[0];
                        
                        }
                        }
                        $tongcon=$tongmo - $a;
            ?>
                        <img src="images/khu.jpg" alt="" width="500">
                        <p class="text-block"> <?php if($tongcon < $tongmo){ echo "Còn $tongcon mộ chưa lập";  }else if($tongcon == $a){echo "Đầy $tongmo/$tongmo";} else{ echo "Còn $tongmo chưa lập mộ";}?></p>
                        <a href="partion-thieunhi.php" class="container">
                            <b class="col_1_of_2 text1 fontdemo">Khu Mộ Thiếu Nhi</b>
                        </a>
                    </div>
                    <div class="span_2_of_3">
                        <img src="images/khu.jpg" alt="" width="500">
                        <p class="text-block">Còn 20 mộ chưa lập</p>
                        <a href="" class="container">
                            <b class="col_1_of_2 text1 fontdemo">Khu Mộ Thiếu Nhi II</b>
                        </a>
                    </div>
                    <div class="span_2_of_3">
                        <?php  
			
            $sql = "SELECT COUNT(*) FROM mobonglai";
            $query = mysqli_query($connect,$sql);
            $result= mysqli_num_rows($query);		  				 
                
            $tongmo=80;
            
            if($query){
                while ( $data =mysqli_fetch_array($query) ) {
                        $a = $data[0];
                        
                        }
                        }
                        $tongcon=$tongmo - $a;
            ?>
                        <img src="images/khu.jpg" alt="" width="500">
                        <p class="text-block">
                            <?php if($tongcon < $tongmo){ echo "Còn $tongcon mộ chưa lập";  }else if($tongcon == $a){echo "Đầy $tongmo/$tongmo";} else{ echo "Còn $tongmo chưa lập mộ";}?>
                        </p>
                        <a href="partion-bonglai.php" class="container">
                            <b class="col_1_of_2 text1 fontdemo">Khu Mộ Bồng Lai</b>
                        </a>
                    </div>


                </div>
            </div>


        </div>

        <div class="clear"></div>
    </div>
    <div class="content-middle">
        <div class="our-mission">
            <div class="ca-container">
                <div class="ca-wrapper">

                    <div class="clear"></div>
                </div>
                <script type="text/javascript">
                $('#ca-container').contentcarousel();
                </script>
            </div>
        </div><br>
        <div class="content-middle-bottom">

            <!-- the jScrollPane script -->
            <script type="text/javascript">
            $('#ca-container1').contentcarousel();
            </script>
        </div>
    </div>

    <div class="heading">

        </a>
        <div class="clear"></div>
    </div>
    <div class="sap_tabs">
        <div id="horizontalTab2">
            <ul class="resp-tabs-list">
                <li>Giới Thiệu</li>
                <li>Mục Đích</li>
                <li>Giải Đáp</li>

                <div class="clear"></div>
            </ul>

            <div class="resp-tabs-container">
                <div class="tab-1">
                    <div class="tab-content">
                        <div class="cont span_2_of_3">
                            <h3><span class="gray">Nội Quy Của Nghĩa Trang Online Trên </span><span class="red">Vĩnh
                                    Hằng</span> </h3>
                            <p>
                                <span class="red">
                                    Quý vị vui lòng bỏ ra chút thời gian để đọc qua những điều này trước khi viếng
                                    mộ</span><br>
                                Đây là nơi tưởng nhớ người đã khuất, chia sẻ những nỗi mất mát đau buồn . Nơi ghi dấu
                                một sự ra đi, những lời cầu chúc đến người đã ở thế giới bên kia ...
                                Nơi của sự tôn nghiêm, linh thiêng... Nơi không còn thù oán và sân si. Vì vậy trước khi
                                vào đây mong bạn cân nhắc những điều sau :
                                <br>+ Tôn trọng, thành kính với người đã Khuất
                                <br>+ Không dùng ngôn ngữ, hành vi coi thường, lăng mạ, ảnh hưởng đến người quá cố cũng
                                như các thành viên khác... Xin hãy để sự bình yên ở lại nơi này.
                                <br>+ Tôn trọng chính bản thân mình, không mạo danh phát ngôn bất kính . Xin bỏ hết
                                những nỗi oán thù cá nhân. Mong sự linh thiêng làm chứng.
                                <br>+ Đây là nơi trang nghiêm tưởng niệm người đã khuất . Xin đừng mạo danh, spam, lấy
                                sự sống chết của mình và người khác ra làm trò đùa.
                                <br>+ Mong quý vị gởi tố cáo, thông báo với chúng tôi qua kênh liên hệ :<span
                                    class="blue"><a href="" class="blue">LIÊN HỆ
                                        VỚI
                                        CHÚNG TÔI</a> </span>nếu thấy hành vi có vi phạm hoặc có sai sót
                                gì ... để chúng tôi kịp thời chỉnh sửa
                            </p>
                        </div>

                        <div class="clear"></div>
                    </div>
                </div>
                <div class="tab-2">
                    <div class="tab-content">
                        <div class="cont span_2_of_3">
                            <h3><span class="gray">Mục Đích Của Nghĩa Trang Online</span></h3>
                            <p>
                                Chúng tôi lập nên nghĩa trang online này với mục đích chính là đáp ứng nhu cầu tâm linh
                                của mọi người .
                                Nhất là những quý vị ở xa lâu ngày không được về thăm mộ người thân .
                                Là nơi tâm sự , an ủi lẫn nhau của mọi người trong gia đình , bạn bè...
                                Hay để bày tỏ sự tiếc thương, tình cảm với những con vật đã gắn bó với mình lâu dài ...
                            </p>
                        </div>
                        <div class="rsidebar span_1_of_3">

                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="tab-3">
                    <div class="tab-content">
                        <div class="cont span_2_of_3">
                            <h3><span class="gray">Giải Đáp Thắc Mắc</span></h3>
                            <p>
                                <span class="red"> Khi tôi lập một ngôi mộ trên Website này thì thời gian tồn tại của mộ
                                    là bao lâu ?</span>
                                <br>+ Khi bạn lập một ngôi mộ trên website này . Thời hạn tồn tại của mộ là vĩnh viễn
                                cùng sự phát triển của Website.
                                Mộ chỉ bị xóa nếu bạn vi phạm các điều nội quy đã quy định .
                                <br><span class="red">Hoặc bạn sử dụng chức năng xóa mộ khi có mật khẩu quản lý
                                    Tương lại ứng dụng này có được phát triển tiếp hay không ?</span>
                                <br>+ Chúng tôi luôn luôn kiểm tra định kỳ và phát triển các chức năng thường xuyên .
                                Hiện tại Mộ Online đã có các chức năng căn bản mà không có website nào có được như :
                                Thắp Hương, chọn biểu tượng tôn giáo, tâm sự, Đọc kinh...
                                Rất mong những ý kiến đóng góp của các bạn để website ngày càng phát triển!.
                                <br><span class="red">Tại sao lại phải xác nhận Email mới được lập mộ ?</span>
                                <br>+ Như các bạn thấy mỗi khu mộ ở đây chỉ có 100 vị trí và tồn tại vĩnh viễn.
                                Ứng dụng này hoàn toàn nghiêm túc. Chúng tôi không muốn bị ảnh hưởng bởi những hành vi
                                phá hoại của các thành viên tiêu cực , lập Mộ để trêu chọc bạn bè phá phách nhau...
                                Để đảm bảo tính linh thiêng , trang nghiêm của mọi ngôi mộ. Chúng tôi bắt buộc phải kiểm
                                tra nghiêm ngặt để thông tin được đảm bảo chính xác nhất .
                                Ngoài ra nếu bạn cảm thấy không muốn xác nhận Email có thể <span class="blue"><a href=""
                                        class="blue">LIÊN HỆ VỚI
                                        CHÚNG TÔI</a> </span> cung cấp thông tin chính xác người đã
                                khuất để chúng tôi cung cấp miễn phí mã code có giá trị tương đương với việc bạn xác
                                nhận Email . Sau thời gian 24-48h ! hoàn toàn miễn phí.
                            <div class="clear"></div>
                            </p>
                        </div>
                        <div class="rsidebar span_1_of_3">
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>

                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
            <br />

        </div>

    </div>
    </div>

    <div class="footer">
        <div class="wrap">
            <div class="bottom-content">
                <div class="col_1_of_footer span_1_of_footer">
                    <div class="footer-logo">
                        <div class="clear"></div>
                    </div>
                    <div class="footer-border">

                        <div class="clear"></div>
                    </div>
                </div>
                <div class="col_1_of_footer span_1_of_footer1">
                    <div class="col_1_of_footer span_1_of_footer">
                        <div class="sidebar-nav">
                            <div class="clear"></div>
                        </div>
                    </div>

                </div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
        <div class="copy">
            <p class="copy">© 2020 Designed by <a href="">Vĩnh Hằng</a> </p>
        </div>
    </div>
    </div>
</body>
<style>
.main {
    padding-bottom: 0px;

}

.text-block {
    position: relative;
    bottom: 10px;
    right: 20px;
    background-color: palegoldenrod;
    opacity: 0.9;
    width: 390px;
    padding-left: 10px;
    padding-right: 10px;
    text-align: center;
}

#myBtn {
    display: none;
    position: fixed;
    bottom: 20px;
    right: 30px;
    z-index: 99;
    font-size: 18px;
    border: none;
    outline: none;
    background-color: #0674ec;
    color: white;
    cursor: pointer;
    padding: 15px;
    border-radius: 30px;
}

@font-face {
    font-family: "Azuki OT W05 Medium";
    /* src: url("fonts/f5b4e198-37f0-4e50-a5b8-a5c84fad7396.woff2") format("woff2"), url("fonts/a5d667b4-3e10-48a3-b45f-1ca8ea3abced.woff") format("woff"); */
    src: url("fonts/UTM Azuki.ttf") format("truetype");
}

.fontdemo {

    font-family: "Azuki OT W05 Medium";
    font-size: 0.89em;
    padding: 0.5em 0;
    color: #555;
    line-height: 1.8em;
    text-align: center;
}

b.text1 {
    background: #F58972;
    padding: 10px;
    color: #FFF;
    font-size: 1em;
    text-transform: uppercase;
    /* font-family: 'Droid Sans', sans-serif; */
}

.number {
    color: white;
    text-align: center;
    background-color: lightblue;
    font-family: verdana;
    font-size: 20px;
    margin-top: 10px;
}

span.blue {
    color: seagreen;
}

span.gray {
    color: sienna;
}

a {
    color: green;
}

#myBtn:hover {
    background-color: #0674ec;
    opacity: 0.9;
}

#snackbar {
    visibility: hidden;
    min-width: 150px;
    margin-left: -125px;
    background-color: #0674ec;
    color: #fff;
    text-align: center;
    border-radius: 10px;
    padding: 16px;
    position: fixed;
    z-index: 1;
    left: 50%;
    bottom: 30px;
    font-size: 17px;
    opacity: 0.9;
}

#snackbar.show {
    visibility: visible;
    -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
    animation: fadein 0.5s, fadeout 0.5s 2.5s;
    opacity: 0.9;
}

@-webkit-keyframes fadein {
    from {
        bottom: 0;
        opacity: 0;
    }

    to {
        bottom: 30px;
        opacity: 1;
    }
}

@keyframes fadein {
    from {
        bottom: 0;
        opacity: 0;
    }

    to {
        bottom: 30px;
        opacity: 1;
    }
}

@-webkit-keyframes fadeout {
    from {
        bottom: 30px;
        opacity: 1;
    }

    to {
        bottom: 0;
        opacity: 0;
    }
}

@keyframes fadeout {
    from {
        bottom: 30px;
        opacity: 1;
    }

    to {
        bottom: 0;
        opacity: 0;
    }
}
</style>

</html>


<script>
//Get the button
var mybutton = document.getElementById("myBtn");
var xa = document.getElementById("snackbar");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {
    scrollFunction()
};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
        xa.className = "show";
    } else {
        mybutton.style.display = "none";
        xa.className = xa.className.replace("show", "");
        // setTimeout(function() {

        // }, 1000);
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>
<script type="text/javascript">
$(document).ready(function() {
    $('#horizontalTab2').easyResponsiveTabs({
        type: 'default', //Types: default, vertical, accordion
        width: 'auto', //auto or any width like 600px
        fit: true // 100% fit in a container
    });
});
</script>
<script>
var snol = [9, 16, 27, 31, 42, 56, 61, 77, 82, 93, 106, 113, 129, 138, 141, 157, 163, 177, 184, 199,
    203, 217, 228, 123
];
$(window).scroll(function() {
    if ($(window).scrollTop() >= 150) {
        // $('#nut_top_phone,#nut_back_phone,#nut_songuoi_online').fadeIn(10);
        var d = new Date();
        var n = d.getHours();
        var snon_ok = snol[n] + d.getMinutes();
        $("#molsnol").text(snon_ok);
        if (d.getSeconds() % 5 == 0) {
            snon_ok = snol[n] + d.getMinutes() + (Math.floor(Math.random() * 5));
            $("#molsnol").text(snon_ok);
        }
    } else {
        //  $('#nut_top_phone,#nut_back_phone,#nut_songuoi_online').fadeOut(10);
    }
});
</script>