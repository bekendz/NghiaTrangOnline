<!DOCTYPE HTML>
<html>

<head>
    <title>Cổng Khu Mộ Vạn An</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script src="js/login.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/51b7f16ab3.js" crossorigin="anonymous"></script>
    <link rel="icon" href="images/icon.png">
</head>

<body>
    <div class="footer">
        <div class="wrap">
            <div class="header-top">
                <div class="header-left">

                    <div class="cssmenu">
                        <ul>
                            <li><a href="trangchu.php"><span>Trang Chủ</span></a></li>
                            <!-- <li class=""><a href="khumo.php"><span>Khu Mộ</span></a></li> -->

                            <!-- <li class="last"><a href="contact.html"><span>Liên Hệ</span></a></li> -->
                            <div class="clear"></div>
                        </ul>
                    </div>
                </div>
                <div class="header-right">


                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
    <div class="product-main">
        <div class="wrap">
            <ul class="breadcrumb">
                <li><a href="trangchu.php">Trang Chủ</a></li>
                <li>Cổng Khu Mộ Vạn An</li>
                <li></li>
                <!-- <li><a href="#">Summer 15</a></li>
  <li>Italy</li>-->
            </ul>
            <div class="products-top">
                <div class="contact-form">
                    <script data-ad-client="ca-pub-9755902253125260" async
                        src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                   
                    <div class="clear"></div>
                </div>
                <center>
                    <div class="container">
                        <h2 class="">Bạn Đi Vào Khu Linh Thiêng Nào?</h2>
                        <div class="containergi">
                            <img src="images/chua.jpg" alt="Thiên Chúa" class="imagegi">
                            <div class="middlegi">
                                <div class="">
                                    <a href="vanan-Chua.php" name="ThienChua" id="ThienChua">
                                        <p class="col_1_of_2 text1">Thiên Chúa</p>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="containergi">
                            <img src="images/daophat.jpg" alt="Đức Phật" class="imagegi">
                            <div class="middlegi">
                                <div class="">
                                    <a href="vanan-Phat.php">
                                        <p class="col_1_of_2 text1">Đức Phật</p>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <br>
                        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                    <!-- NghiaTrangOnline -->
                    <ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-9755902253125260"
                        data-ad-slot="2322518266" data-ad-format="auto" data-full-width-responsive="true"></ins>
                    <script>
                    (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                        <button onclick="topFunction()" id="myBtn" title="" class="fas fa-angle-up"></button>
                        <div class="clear"></div>
                    </div>
                </center>
                <div class="clear"></div>

                <div class="clear"></div>
            </div>


            <div class="clear"></div>
        </div>
    </div>
    </div>
    <div class="footera footer">
        <div class="wrap">
            <div class="bottom-content">
                <div class="col_1_of_footer span_1_of_footer">
                    <div class="footer-logo">
                        <div class="clear"></div>
                    </div>
                    <div class="footer-border">

                        <div class="clear"></div>
                    </div>
                </div>
                <div class="col_1_of_footer span_1_of_footer1">
                    <div class="col_1_of_footer span_1_of_footer">
                        <div class="sidebar-nav">

                        </div>
                    </div>
                    <div class="col_1_of_footer span_1_of_footer">

                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
        <div class="copy">
            <p class="copy">© 2020 Designed by <a href="">Vĩnh Hằng</a> </p>
        </div>
    </div>
    </div>
</body>

</html>

<style>
.footera {
    margin-top: 450px;
}

.text-block {
    position: relative;
    bottom: 95px;
    right: 15px;
    background-color: none;
    color: sienna;
    text-align: center;
    padding-left: 80px;
    padding-right: 50px;
    word-wrap: break-word;
}

h6 {

    font-size: 11px;
}

.textyear {
    position: relative;
    bottom: 90px;
    left: 0px;
}

#myBtn {
    display: none;
    position: fixed;
    bottom: 20px;
    right: 30px;
    z-index: 99;
    font-size: 18px;
    border: none;
    outline: none;
    background-color: #0674ec;
    color: white;
    cursor: pointer;
    padding: 15px;
    border-radius: 50px;
}

#myBtn:hover {
    background-color: #0674ec;
    opacity: 0.9;
}

ul.breadcrumb {
    padding: 10px 16px;
    list-style: none;
    background-color: #eee;
}

ul.breadcrumb li {
    display: inline;
    font-size: 18px;
}

ul.breadcrumb li+li:before {
    padding: 8px;
    color: black;
    content: "/\00a0";
}

ul.breadcrumb li a {
    color: #0275d8;
    text-decoration: none;
}

ul.breadcrumb li a:hover {
    color: #01447e;
    text-decoration: underline;
}

.contact-form input[type="text"],
.contact-form textarea {
    padding: 8px;
    display: block;
    width: 98%;
    background: #fcfcfc;
    border: none;
    outline: none;
    color: #464646;
    font-size: 0.8125em;
    font-family: Arial, Helvetica, sans-serif;
    box-shadow: 0 0 5px #AAA;
    -webkit-box-shadow: 0 0 5px #AAA;
    -moz-box-shadow: 0 0 5px #AAA;
    -o-box-shadow: 0 0 5px #AAA;
    -webkit-appearance: none;
}

.containergi {
    position: relative;
    /* width: 50%; */
    margin: 5px;
    margin-right: 200px;
    border: 0px solid #ccc;
    float: left;
    width: 300px;
}

.imagegi {
    opacity: 1;
    display: block;
    width: 100%;
    height: auto;
    transition: .5s ease;
    backface-visibility: hidden;
}

.middlegi {
    transition: .5s ease;
    opacity: 0;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    text-align: center;
}

.containergi:hover .imagegi {
    opacity: 0.3;
}

.containergi:hover .middlegi {
    opacity: 1;
}

.textgi {
    background-color: #4CAF50;
    color: white;
    font-size: 16px;
    padding: 16px 32px;
}
</style>
<script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {
    scrollFunction()
};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
    } else {
        mybutton.style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>