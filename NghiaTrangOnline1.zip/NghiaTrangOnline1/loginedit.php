<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Nghĩa Trang Online | Đăng Nhập Online</title>
    <link rel="icon" type="image/png" href="assets/images/icon.png">
    <!-- START: Styles -->
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300i,400,400i,700%7cMarcellus+SC"
        rel="stylesheet">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/dist/css/bootstrap.min.css">
    <!-- FontAwesome -->
    <script defer src="assets/vendor/fontawesome-free/js/all.js"></script>
    <script defer src="assets/vendor/fontawesome-free/js/v4-shims.js"></script>
    <!-- IonIcons -->
    <link rel="stylesheet" href="assets/vendor/ionicons/css/ionicons.min.css">
    <!-- Revolution Slider -->
    <link rel="stylesheet" href="assets/vendor/revolution/css/settings.css">
    <link rel="stylesheet" href="assets/vendor/revolution/css/layers.css">
    <link rel="stylesheet" href="assets/vendor/revolution/css/navigation.css">
    <!-- Flickity -->
    <link rel="stylesheet" href="assets/vendor/flickity/dist/flickity.min.css">
    <!-- Photoswipe -->
    <link rel="stylesheet" href="assets/vendor/photoswipe/dist/photoswipe.css">
    <link rel="stylesheet" href="assets/vendor/photoswipe/dist/default-skin/default-skin.css">
    <!-- DateTimePicker -->
    <link rel="stylesheet" href="assets/vendor/jquery-datetimepicker/build/jquery.datetimepicker.min.css">
    <!-- Summernote -->
    <link rel="stylesheet" href="assets/vendor/summernote/dist/summernote-bs4.css">
    <!-- GODLIKE -->
    <link rel="stylesheet" href="assets/css/godlike.css">
    <!-- Custom Styles -->
    <link rel="stylesheet" href="assets/css/custom.css">
    <!-- END: Styles -->
    <!-- jQuery -->
    <script src="assets/vendor/jquery/dist/jquery.min.js"></script>
</head>
<?php  include "ConnectDatabase.php";?>

<body>

    <div class="nk-preloader">

        <div class="nk-preloader-bg" style="background-color: #000;" data-close-frames="23" data-close-speed="1.2"
            data-close-sprites="./assets/images/preloader-bg.png" data-open-frames="23" data-open-speed="1.2"
            data-open-sprites="./assets/images/preloader-bg-bw.png">
        </div>
        <div class="nk-preloader-content">
            <div>
                <!-- <img class="nk-img" src="assets/images/logo.svg" alt="GodLike - Gaming Bootstrap 4 Template"
                    width="170"> -->
                <div class="nk-preloader-animation"></div>
            </div>
        </div>
        <div class="nk-preloader-skip">Skip</div>
    </div>

    <div class="nk-page-background op-5" data-video="https://youtu.be/UkeDo1LhUqQ" data-video-loop="true"
        data-video-mute="true" data-video-volume="0" data-video-start-time="0" data-video-end-time="0"
        data-video-pause-on-page-leave="true" style="background-image: url('assets/images/page-background.jpg');"></div>

    <div class="nk-page-background-audio d-none" data-audio="assets/mp3/purpleplanetmusic-desolation.mp3"
        data-audio-volume="100" data-audio-autoplay="true" data-audio-loop="true" data-audio-pause-on-page-leave="true">
    </div>
    <!-- END: Page Background -->
    <!-- START: Page Border -->
    <div class="nk-page-border">
        <div class="nk-page-border-t"></div>
        <div class="nk-page-border-r"></div>
        <div class="nk-page-border-b"></div>
        <div class="nk-page-border-l"></div>
    </div>

    <header class="nk-header nk-header-opaque">

        <div class="nk-contacts-top">
            <div class="container">

                <div class="nk-contacts-right">
                    <div class="nk-navbar">
                        <ul class="nk-nav">
                            <li><a href="" target="_blank"><span class="ion-social-twitter"></span></a></li>
                            <li><a href="" target="_blank"><span class="ion-social-dribbble-outline"></span></a></li>
                            <li><a href="#"><span class="ion-social-instagram-outline"></span></a></li>
                            <li><a href="#"><span class="ion-social-pinterest"></span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <nav class="nk-navbar nk-navbar-top nk-navbar-sticky nk-navbar-autohide">
            <div class="container">
                <div class="nk-nav-table">
                    <a href="trangchu.php" class="nk-nav-logo">
                        <!-- <img src="assets/images/logo.svg" alt="" width="90"> -->
                        Vĩnh Hằng
                    </a>
                    <ul class="nk-nav nk-nav-right d-none d-lg-block" data-nav-mobile="#nk-nav-mobile">
                        <li class=" ">
                            <a href="trangchu.php"> Trang chủ</a>
                            <!-- <ul class="dropdown">
                                    <li class="  ">
                                        <a href="index.html"> Landing</a>
                                    </li>
                                    <li class="active  ">
                                        <a href="index-main.html"> Main</a>
                                    </li>
                                    <li class="  ">
                                        <a href="index-game-promo.html"> Game Promo</a>
                                    </li>
                                </ul> -->
                        </li>
                        <li class="  nk-drop-item">
                            <a href=""> Khu Vườn</a>
                            <ul class="dropdown">
                                <li class="  nk-drop-item">
                                    <a href=""> Coming Soon</a>
                                    <ul class="dropdown">
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="  nk-drop-item">
                                    <a href=""> Coming Soon</a>
                                    <ul class="dropdown">
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon </a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>

                            </ul>
                        </li>


                        <li class="  nk-drop-item">
                            <a href=""> Cửa Hàng</a>
                            <ul class="dropdown">
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                            </ul>
                        </li>

                    </ul>
                    <ul class="nk-nav nk-nav-right nk-nav-icons">
                        <li class="single-icon d-lg-none">
                            <a href="#" class="no-link-effect" data-nav-toggle="#nk-nav-mobile">
                                <span class="nk-icon-burger">
                                    <span class="nk-t-1"></span>
                                    <span class="nk-t-2"></span>
                                    <span class="nk-t-3"></span>
                                </span>
                            </a>
                        </li>
                        <div class="nk-search">
           
                        <?php
                        session_start();
                       if(isset($_POST['login'])){
                        $username= $_POST['username'];
                        $matkhau =$_POST['password'];
                    
                        if($username ==""|| $matkhau==""){
                            echo "Vui lòng nhập đầy đủ thông tin";
                        }  else  {
                            $sql = "SELECT * FROM account";
                            $query = mysqli_query($connect,$sql);
                            $result= mysqli_num_rows($query);
                            if($result>0 ){  
                                while ( $data =mysqli_fetch_assoc($query) ) {
                                    $usernameB= $data['Username'];
                                    $matkhauA =$data['Password'];	
                                                    
                                        if($username == $usernameB && $matkhau == $matkhauA ){	
                                                echo "Đăng Nhập Thành Công";
                                              $_SESSION["username"] = $username;    
                                             header("Location: http://localhost/NghiaTrangOnline1/trangchu.php");
                                                                                         
                                    }else{										
                                        echo "Đăng Nhập Thất Bại";				
                                    }										   
                            }
                            mysqli_free_result($query);	 	
                        }
                        }
                        mysqli_close($connect);
                                    }									   
                              if(  !isset( $_SESSION["username"])){
                      
                      ?>
                        <li class="single-icon">
                            <a href="#" class="nk-sign-toggle no-link-effect">
                                <span class="nk-icon-toggle">
                                    <span class="nk-icon-toggle-front">
                                        <span class="fa fa-sign-in"></span>
                                    </span>
                                    <span class="nk-icon-toggle-back">
                                        <span class="nk-icon-close"></span>
                                    </span>
                                </span>
                            </a>
                        </li>
                        <?php
                         }  else{

                         
                        
                        ?>
                        <form method="post">
                            <li class="single-icon">
                                <span style="font-size: 14px; ">Xin chào,<br>

                                    <a href="account.php?nameus=<?php echo $_SESSION['username'];?>"><?php echo $_SESSION['username'];?> </a>

                                    <!-- <button name="logout" class="">
                                        <i class="fa fa-sign-in"></i>
                                    </button> -->

                            </li>

                            </span>

                            </li>
                        </form>
                        <?php } 
                         if(isset($_POST['logout'])){                          
                            session_unset();
                            header("Location: http://localhost/NghiaTrangOnline1/trangchu.php");
                        }
                        ?>

                    </ul>
                </div>
            </div>
        </nav>


    </header>


    <div id="nk-nav-mobile" class="nk-navbar nk-navbar-side nk-navbar-left-side nk-navbar-overlay-content d-lg-none">
        <div class="nano">
            <div class="nano-content">
                <a href="trangchu.php" class="nk-nav-logo">
                    <!-- <img src="assets/images/logo.svg" alt="" width="90"> -->
                    Vĩnh Hằng
                </a>
                <div class="nk-navbar-mobile-content">
                    <ul class="nk-nav">
                        <!-- Here will be inserted menu from [data-mobile-menu="#nk-nav-mobile"] -->
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-main">

        <div class="nk-header-title nk-header-title-sm nk-header-title-parallax nk-header-title-parallax-opacity">
            <div class="bg-image">
                <img src="assets/images/image-1.jpg" alt="" class="jarallax-img">
            </div>
            <div class="nk-header-table">
                <div class="nk-header-table-cell">
                    <div class="container">
                        <h1 class="nk-title">Đăng Nhập </h1>
                        <!-- <h2 class="nk-sub-title">Working AJAX Forms</h2> -->
                    </div>
                </div>
            </div>
        </div>
        <!-- END: Header Title -->
        <div class="nk-gap-4"></div>
        <div class="container">
            <div class="">
                <div class="">

                    <div class="">

                        <div class="nk-box-5">
                            <!-- <h2 class="nk-title h3 text-center">Lập Mộ Online Tại - <?php echo $khulap;?> - Số mộ:
                                <?php echo $somo;?></h2>  -->
                            <div class="nk-gap-1"></div>
                            <!-- START: Form 2 -->
                            <form method="post">
                                <!-- <input type="text" class="form-control " name="username" placeholder="Username *">
                           <div class="nk-gap"></div> -->
                                <input type="password" class="form-control " name="passwordA"
                                    placeholder="Vui lòng nhập mật khẩu *">
                                <div class="nk-gap"></div>
                                <button class="nk-btn nk-btn-lg link-effect-4" name="loginedit">Đăng Nhập</button>
                                <button class="nk-btn nk-btn-lg link-effect-4" name="cancel">Đóng</button>
                            </form>
                            <?php
                            $ids=$_GET['ID'];
                            $nameus=$_GET['name'];
                            $nameten=$_GET['ten'];
                            $idkmt=$_GET['KMID'];
                            $daom= $_GET['Dao'];
                            $daomt= $_GET['Dao1'];
                            $idkd=$_GET['ID'];
                       if(isset($_POST['loginedit'])){
                   
                        $matkhau =$_POST['passwordA'];
                     
                        if($matkhau==""){
                            echo "Vui lòng nhập đầy đủ thông tin";
                        }  else  {
                            $sql = "SELECT * FROM mo Where ID='$ids'";
                            $query = mysqli_query($connect,$sql);
                            $result= mysqli_num_rows($query);
                            if($result>0 ){  
                                while ( $login =mysqli_fetch_assoc($query) ) { 
                                    $matkhauA =$login['MatKhau'];	          
                                        if($matkhau == $matkhauA ){	
                                                echo "Đăng Nhập Thành Công";   
                                             header("Location: http://localhost/NghiaTrangOnline1/editheadstone.php?name=$nameus&ten=$nameten&KMID=$idkmt&Dao=$daom&Dao1=$daomt&ID=$idkd");
                                                                                         
                                    }else{										
                                        echo "Đăng Nhập Thất Bại";				
                                    }										   
                            }
                            mysqli_free_result($query);	 	
                        }
                        }
                        mysqli_close($connect);
                                    }
                                    if(isset($_POST['cancel'])){
                                        header("Location: http://localhost/NghiaTrangOnline1/mochitiet.php?name=$nameus&ten=$nameten&KMID=$idkmt&Dao=$daom&Dao1=$daomt&ID=$idkd");
                                    }
                     ?>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="nk-gap-1"></div>

            </div>
            <div class="nk-gap-4"></div>
            <div class="nk-gap-4"></div>

            <footer class="nk-footer nk-footer-parallax nk-footer-parallax-opacity">
                <img class="nk-footer-top-corner" src="assets/images/footer-corner.png" alt="">
                <div class="container">
                    <div class="nk-gap-2"></div>

                    <div class="nk-gap"></div>
                    <p> &copy; 2020 Design by nK Group Inc. </p>
                    <div class="nk-gap-4"></div>
                </div>
            </footer>
            <!-- END: Footer -->
        </div>

        <div class="nk-share-buttons nk-share-buttons-left d-none d-md-flex">
            <ul>
                <li>
                    <span class="nk-share-icon" title="Share page on Facebook" data-share="facebook">
                        <span class="icon fa fa-facebook"></span>
                    </span>
                    <span class="nk-share-name">Facebook</span>
                </li>
                <li>
                    <span class="nk-share-icon" title="Share page on Twitter" data-share="twitter">
                        <span class="icon fa fa-twitter"></span>
                    </span>
                    <span class="nk-share-name">Twitter</span>
                </li>


            </ul>
        </div>
        <div class="nk-side-buttons nk-side-buttons-visible">
            <ul>

                <li>
                    <span class="nk-btn nk-btn-lg nk-btn-icon nk-bg-audio-toggle">
                        <span class="icon">
                            <span class="ion-android-volume-up nk-bg-audio-pause-icon"></span>
                            <span class="ion-android-volume-off nk-bg-audio-play-icon"></span>
                        </span>
                    </span>
                </li>
                <li class="nk-scroll-top">
                    <span class="nk-btn nk-btn-lg nk-btn-icon">
                        <span class="icon ion-ios-arrow-up"></span>
                    </span>
                </li>
            </ul>
        </div>

        <div class="nk-search">
            <div class="container">
                <form action="#">
                    <fieldset class="form-group nk-search-field">
                        <input type="text" class="form-control" id="searchInput" placeholder="Search..." name="s">
                        <label for="searchInput"><i class="ion-ios-search"></i></label>
                    </fieldset>
                </form>
            </div>
        </div>


        <div class="nk-sign-form">
            <div class="nk-gap-5"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 offset-lg-4 col-md-6 offset-md-3">
                        <div class="nk-sign-form-container">
                            <div class="nk-sign-form-toggle h3">
                                <a href="#" class="nk-sign-form-login-toggle active">Đăng Nhập</a>
                                <a href="#" class="nk-sign-form-register-toggle">Đăng Ký</a>
                            </div>
                            <div class="nk-gap-2"></div>

                            <form class="nk-sign-form-login active" action="#">
                                <input class="form-control" type="text" placeholder="Username or Email">
                                <div class="nk-gap-2"></div>
                                <input class="form-control" type="password" placeholder="Password">
                                <div class="nk-gap-2"></div>
                                <div class="form-check float-left">
                                    <label class="form-check-label">
                                        <input type="checkbox" class="form-check-input"> Remember Me </label>
                                </div>
                                <button class="nk-btn nk-btn-color-white link-effect-4 float-right">Đăng Nhập</button>
                                <div class="clearfix"></div>
                                <div class="nk-gap-1"></div>
                                <a class="nk-sign-form-lost-toggle float-right" href="#">Quên Mật Khẩu?</a>
                            </form>

                            <form class="nk-sign-form-lost" action="#">
                                <input class="form-control" type="text" placeholder="Username or Email">
                                <div class="nk-gap-2"></div>
                                <button class="nk-btn nk-btn-color-white link-effect-4 float-right">Đổi Mật
                                    Khẩu</button>
                            </form>

                            <form class="nk-sign-form-register" action="#">
                                <input class="form-control" type="text" placeholder="Username">
                                <div class="nk-gap-2"></div>
                                <input class="form-control" type="password" placeholder="Mật Khẩu">
                                <div class="nk-gap-2"></div>
                                <input class="form-control" type="email" placeholder="Email">
                                <div class="nk-gap-2"></div>
                                <input class="form-control" type="text" placeholder="Họ Và Tên">
                                <div class="nk-gap-2"></div>
                                <input class="form-control" type="tel" placeholder="Điện Thoại">
                                <div class="nk-gap-2"></div>

                                <button class="nk-btn nk-btn-color-white link-effect-4 float-right">Đăng Ký</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <div class="nk-gap-5"></div>
        </div>
        <!-- END: Sign Form -->
        <!-- START: Scripts -->
        <!-- Object Fit Polyfill -->
        <script src="assets/vendor/object-fit-images/dist/ofi.min.js"></script>
        <!-- GSAP -->
        <script src="assets/vendor/gsap/dist/gsap.min.js"></script>
        <script src="assets/vendor/gsap/dist/ScrollToPlugin.min.js"></script>
        <!-- Popper -->
        <script src="assets/vendor/popper.js/dist/umd/popper.min.js"></script>
        <!-- Bootstrap -->
        <script src="assets/vendor/bootstrap/dist/js/bootstrap.min.js"></script>
        <!-- Sticky Kit -->
        <script src="assets/vendor/sticky-kit/dist/sticky-kit.min.js"></script>
        <!-- Jarallax -->
        <script src="assets/vendor/jarallax/dist/jarallax.min.js"></script>
        <script src="assets/vendor/jarallax/dist/jarallax-video.min.js"></script>
        <!-- imagesLoaded -->
        <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
        <!-- Flickity -->
        <script src="assets/vendor/flickity/dist/flickity.pkgd.min.js"></script>
        <!-- Isotope -->
        <script src="assets/vendor/isotope-layout/dist/isotope.pkgd.min.js"></script>
        <!-- Photoswipe -->
        <script src="assets/vendor/photoswipe/dist/photoswipe.min.js"></script>
        <script src="assets/vendor/photoswipe/dist/photoswipe-ui-default.min.js"></script>
        <!-- Typed.js -->
        <script src="assets/vendor/typed.js/lib/typed.min.js"></script>
        <!-- Jquery Validation -->
        <script src="assets/vendor/jquery-validation/dist/jquery.validate.min.js"></script>
        <!-- Jquery Countdown + Moment -->
        <script src="assets/vendor/jquery-countdown/dist/jquery.countdown.min.js"></script>
        <script src="assets/vendor/moment/min/moment.min.js"></script>
        <script src="assets/vendor/moment-timezone/builds/moment-timezone-with-data.min.js"></script>
        <!-- Hammer.js -->
        <script src="assets/vendor/hammerjs/hammer.min.js"></script>
        <!-- NanoSroller -->
        <script src="assets/vendor/nanoscroller/bin/javascripts/jquery.nanoscroller.js"></script>
        <!-- SoundManager2 -->
        <script src="assets/vendor/soundmanager2/script/soundmanager2-nodebug-jsmin.js"></script>
        <!-- DateTimePicker -->
        <script src="assets/vendor/jquery-datetimepicker/build/jquery.datetimepicker.full.min.js"></script>
        <!-- Revolution Slider -->
        <script src="assets/vendor/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script src="assets/vendor/revolution/js/jquery.themepunch.revolution.min.js"></script>
        <script src="assets/vendor/revolution/js/extensions/revolution.extension.video.min.js"></script>
        <script src="assets/vendor/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
        <script src="assets/vendor/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
        <!-- Keymaster -->
        <script src="assets/vendor/keymaster/keymaster.js"></script>
        <!-- Summernote -->
        <script src="assets/vendor/summernote/dist/summernote-bs4.min.js"></script>
        <!-- GODLIKE -->
        <script src="assets/js/godlike.min.js"></script>
        <script src="assets/js/godlike-init.js"></script>
        <!-- END: Scripts -->
        <style>
        [type=radio]:checked+img {
            outline: 2px solid green;

        }

        ul {
            list-style-type: none;
        }

        li {
            display: inline-block;
        }

        input[type="radio"] {
            display: none;
        }

        .imgcheck {
            border: 1px solid #fff;
            padding: 10px;
            display: block;
            position: relative;
            margin: 10px;
            cursor: pointer;
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        label::before {
            background-color: white;
            color: white;
            content: " ";
            display: block;
            border-radius: 50%;
            border: 1px solid grey;
            position: absolute;
            top: -5px;
            left: -5px;
            width: 25px;
            height: 25px;
            text-align: center;
            line-height: 28px;
            transition-duration: 0.4s;
            transform: scale(0);
        }

        label img {
            height: 100px;
            width: 100px;
            transition-duration: 0.2s;
            transform-origin: 50% 50%;
        }

        :checked+label {
            border-color: green;
        }

        :checked+label::before {
            content: "✓";
            background-color: green;
            transform: scale(1);

        }

        :checked+label img {
            transform: scale(0.9);
            box-shadow: 0 0 5px #333;
            z-index: -1;
        }
        </style>
</body>

</html>