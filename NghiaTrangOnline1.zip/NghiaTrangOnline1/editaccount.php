<!DOCTYPE html>
<?php 
 include "ConnectDatabase.php";
         session_start();            
                     ?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="_nK">
    <title>Nghĩa Trang Online | Thay Đổi Thông Tin Tài Khoản</title>
    <link rel="icon" type="image/png" href="assets/images/logovh.ico">
    <!-- START: Styles -->
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300i,400,400i,700%7cMarcellus+SC"
        rel="stylesheet">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/dist/css/bootstrap.min.css">
    <!-- FontAwesome -->
    <script defer src="assets/vendor/fontawesome-free/js/all.js"></script>
    <script defer src="assets/vendor/fontawesome-free/js/v4-shims.js"></script>
    <!-- IonIcons -->
    <link rel="stylesheet" href="assets/vendor/ionicons/css/ionicons.min.css">
    <!-- Revolution Slider -->
    <link rel="stylesheet" href="assets/vendor/revolution/css/settings.css">
    <link rel="stylesheet" href="assets/vendor/revolution/css/layers.css">
    <link rel="stylesheet" href="assets/vendor/revolution/css/navigation.css">
    <!-- Flickity -->
    <link rel="stylesheet" href="assets/vendor/flickity/dist/flickity.min.css">
    <!-- Photoswipe -->
    <link rel="stylesheet" href="assets/vendor/photoswipe/dist/photoswipe.css">
    <link rel="stylesheet" href="assets/vendor/photoswipe/dist/default-skin/default-skin.css">
    <!-- DateTimePicker -->
    <link rel="stylesheet" href="assets/vendor/jquery-datetimepicker/build/jquery.datetimepicker.min.css">
    <!-- Summernote -->
    <link rel="stylesheet" href="assets/vendor/summernote/dist/summernote-bs4.css">
    <!-- GODLIKE -->
    <link rel="stylesheet" href="assets/css/godlike.css">
    <!-- Custom Styles -->
    <link rel="stylesheet" href="assets/css/custom.css">
    <!-- END: Styles -->
    <!-- jQuery -->
    <script src="assets/vendor/jquery/dist/jquery.min.js"></script>
</head>

<body>
    <div class="nk-preloader">
        <div class="nk-preloader-bg" style="background-color: #000;" data-close-frames="23" data-close-speed="1.2"
            data-close-sprites="./assets/images/preloader-bg.png" data-open-frames="23" data-open-speed="1.2"
            data-open-sprites="./assets/images/preloader-bg-bw.png">
        </div>
        <div class="nk-preloader-content">
            <div>
                <img src="assets/images/logovh.png" alt="" width="170">
                <div class="nk-preloader-animation"></div>
            </div>
        </div>
        <div class="nk-preloader-skip">Skip</div>
    </div>
    <div class="nk-page-background op-5" data-video="https://youtu.be/UkeDo1LhUqQ" data-video-loop="true"
        data-video-mute="true" data-video-volume="0" data-video-start-time="0" data-video-end-time="0"
        data-video-pause-on-page-leave="true" style="background-image: url('assets/images/page-background.jpg');"></div>

    <div class="nk-page-background-audio d-none" data-audio="assets/mp3/purpleplanetmusic-desolation.mp3"
        data-audio-volume="100" data-audio-autoplay="true" data-audio-loop="true" data-audio-pause-on-page-leave="true">
    </div>

    <div class="nk-page-border">
        <div class="nk-page-border-t"></div>
        <div class="nk-page-border-r"></div>
        <div class="nk-page-border-b"></div>
        <div class="nk-page-border-l"></div>
    </div>

    <header class="nk-header nk-header-opaque">

        <div class="nk-contacts-top">
            <div class="container">
                <div class="nk-contacts-left">
                    <div class="nk-navbar">

                    </div>
                </div>
                <div class="nk-contacts-right">
                    <div class="nk-navbar">
                        <ul class="nk-nav">
                            <li><a href="" target="_blank"><span class="ion-social-twitter"></span></a></li>
                            <li><a href="" target="_blank"><span class="ion-social-dribbble-outline"></span></a></li>
                            <li><a href="#"><span class="ion-social-instagram-outline"></span></a></li>
                            <li><a href="#"><span class="ion-social-pinterest"></span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <nav class="nk-navbar nk-navbar-top nk-navbar-sticky nk-navbar-autohide">
            <div class="container">
                <div class="nk-nav-table">
                    <a href="trangchu.php" class="nk-nav-logo">
                        <img src="assets/images/logovh.png" alt="" width="90">
                    </a>
                    <ul class="nk-nav nk-nav-right d-none d-lg-block" data-nav-mobile="#nk-nav-mobile">
                        <li class=" ">
                            <a href="trangchu.php"> Trang chủ</a>
                        </li>
                        <li class="  nk-drop-item">
                            <a href=""> Khu Vườn</a>
                            <ul class="dropdown">
                                <li class="  nk-drop-item">
                                    <a href=""> Coming Soon</a>
                                    <ul class="dropdown">
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="  nk-drop-item">
                                    <a href=""> Coming Soon</a>
                                    <ul class="dropdown">
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon </a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>

                            </ul>
                        </li>


                        <li class="  nk-drop-item">
                            <a href=""> Cửa Hàng</a>
                            <ul class="dropdown">
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                            </ul>
                        </li>

                    </ul>
                    <ul class="nk-nav nk-nav-right nk-nav-icons">
                        <li class="single-icon d-lg-none">
                            <a href="#" class="no-link-effect" data-nav-toggle="#nk-nav-mobile">
                                <span class="nk-icon-burger">
                                    <span class="nk-t-1"></span>
                                    <span class="nk-t-2"></span>
                                    <span class="nk-t-3"></span>
                                </span>
                            </a>
                        </li>
                        <?php                    
                       if(isset($_POST['login'])){
                        $username= $_POST['username'];
                        $matkhau =$_POST['password'];
                     
                        if($username ==""|| $matkhau==""){
                            echo "Vui lòng nhập đầy đủ thông tin";
                        }  else  {
                            $sql = "SELECT * FROM account";
                            $query = mysqli_query($connect,$sql);
                            $result= mysqli_num_rows($query);
                            if($result>0 ){  
                                while ( $data =mysqli_fetch_assoc($query) ) {
                                    $usernameB= $data['Username'];
                                    $matkhauA =$data['Password'];	
                                                    
                                        if($username == $usernameB && $matkhau == $matkhauA ){	
                                                echo "Đăng Nhập Thành Công";
                                              $_SESSION["username"] = $username;    
                                             header("Location: http://localhost/NghiaTrangOnline1/trangchu.php");
                                                                                         
                                    }else{										
                                        echo "Đăng Nhập Thất Bại";				
                                    }										   
                            }
                            mysqli_free_result($query);	 	
                        }
                        }
                        mysqli_close($connect);
                                    }									   
                              if(  !isset( $_SESSION["username"])){
                      
                      ?>
                        <li class="single-icon">
                            <a href="#" class="nk-sign-toggle no-link-effect">
                                <span class="nk-icon-toggle">
                                    <span class="nk-icon-toggle-front">
                                        <span class="fa fa-sign-in"></span>
                                    </span>
                                    <span class="nk-icon-toggle-back">
                                        <span class="nk-icon-close"></span>
                                    </span>
                                </span>
                            </a>
                        </li>
                        <?php
                         }  else{           
                        
                        ?>
                        <form method="post">
                            <li class="single-icon">
                                <span style="font-size: 14px; ">Xin chào,<br>
                                    <a href="info.php?nameus=<?php echo $_GET['nameus'];?>"><?php echo $_SESSION['username'];?>
                                    </a>
                            </li>
                            </span>

                            </li>
                        </form>
                        <?php } 
                         if(isset($_POST['logout'])){                          
                            session_unset();
                            header("Location: http://localhost/NghiaTrangOnline1/trangchu.php");
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>

    </header>
    <div id="nk-nav-mobile" class="nk-navbar nk-navbar-side nk-navbar-left-side nk-navbar-overlay-content d-lg-none">
        <div class="nano">
            <div class="nano-content">
                <a href="trangchu.php" class="nk-nav-logo">
                    <img src="assets/images/logovh.png" alt="" width="90">
                </a>
                <div class="nk-navbar-mobile-content">
                    <ul class="nk-nav">
                        <!-- Here will be inserted menu from [data-mobile-menu="#nk-nav-mobile"] -->
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- END: Navbar Mobile -->
    <div class="nk-main">

        <div class="nk-header-title nk-header-title-sm nk-header-title-parallax nk-header-title-parallax-opacity">
            <div class="bg-image op-5">
                <!-- <img src="assets/images/image-5.jpg" alt="" class="jarallax-img"> -->
            </div>
            <div class="nk-header-table">
                <div class="nk-header-table-cell">
                    <div class="container">
                    </div>
                </div>
            </div>
        </div>
        <!-- END: Header Title -->
        <div class="container">
            <div class="nk-social-profile nk-social-profile-container-offset">
                <div class="row">
                    <div class="col-md-5 col-lg-3">
                        <div class="nk-social-profile-avatar">
                            <a href="">
                                <img src="assets/images/av-fb.jpg" alt="nK" style="border-radius: 50%; width: 150px;">
                            </a>
                        </div>
                    </div>
                    <?php
                        $usm = $_SESSION['username'];
                         $sql = "SELECT * FROM account Where Username='$usm'";
                         $query = mysqli_query($connect,$sql);
                         $result= mysqli_num_rows($query);
                         if($result>0 ){  
                             while ( $data =mysqli_fetch_assoc($query) ) {
                                 
                        ?>
                    <div class="col-md-7 col-lg-9">
                        <div class="nk-social-profile-info">
                            <div class="nk-gap-2"></div>
                            <h1 class="nk-social-profile-info-name"><?php echo $data['HovaTen'];?></h1>
                            <div class="nk-social-profile-info-username">@<?php echo $data['Username'];?></div>
                            <div class="nk-social-profile-info-actions">
                                <?php    }
                            }?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row vertical-gap">
                <div class="col-lg-3">

                    <aside class="nk-sidebar nk-sidebar-left nk-sidebar-sticky">
                        <div class="nk-gap-2"></div>
                        <div class="nk-social-menu d-none d-lg-block">
                            <ul>
                                <li class="">
                                    <a href="info.php?nameus=<?php echo $_GET['nameus'];?>"> Thông tin</a>
                                </li>
                                <li class="">
                                    <a href="account.php?nameus=<?php echo $_GET['nameus'];?>"> Mộ đã lập</a>
                                </li>
                                <li class="active">
                                    <a href="editaccount.php?nameus=<?php echo $_GET['nameus'];?>"> Thay đổi thông
                                        tin</a>
                                </li>
                                <li class="">
                                    <a href=""> Đổi mật khẩu</a>
                                </li>
                            </ul>
                        </div>
                        <div class="nk-accordion d-lg-none" id="nk-social-menu-mobile" role="tablist"
                            aria-multiselectable="true">
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="nk-social-menu-mobile-1-heading">
                                    <a data-toggle="collapse" data-parent="#nk-social-menu-mobile"
                                        href="#nk-social-menu-mobile-1" aria-expanded="true"
                                        aria-controls="nk-social-menu-mobile-1" class="collapsed"> Menu </a>
                                </div>
                                <div id="nk-social-menu-mobile-1" class="panel-collapse collapse" role="tabpanel"
                                    aria-labelledby="nk-social-menu-mobile-1-heading">
                                    <div class="nk-social-menu">
                                        <ul>
                                            <li class="">
                                                <a href="info.php?nameus=<?php echo $_GET['nameus'];?>"> Thông
                                                    tin</a>
                                            </li>
                                            <li class="">
                                                <a href="account.php?nameus=<?php echo $_GET['nameus'];?>"> Mộ đã
                                                    lập</a>
                                            </li>
                                            <li class="active">
                                                <a href="editaccount.php?nameus=<?php echo $_GET['nameus'];?>"> Thay đổi
                                                    thông tin</a>
                                            </li>
                                            <li class="">
                                                <a href=""> Đổi mật khẩu</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="nk-gap-4 d-none d-lg-block"></div>
                    </aside>
                    <!-- END: Sidebar -->
                </div>
                <div class="col-lg-9">
                    <div class="nk-gap-2 d-none d-lg-block"></div>

                    <div class="nk-social-container">

                        <form method="POST">
                            <?php  
                        $sql = "SELECT * FROM account Where Username='$usm'";
                        $query = mysqli_query($connect,$sql);
                        $result= mysqli_num_rows($query);
                        if($result>0 ){  
                            while ( $sua =mysqli_fetch_array($query) ) {
                        
                        ?>
                            <h6>Họ Và Tên</h6>
                            <input type="text" class="form-control" placeholder="Họ Và Tên"
                                value="<?php echo $sua[4];?>" name="htup">
                            <div class="nk-gap"></div>
                            <h6>Email</h6>
                            <input type="email" class="form-control" placeholder="Email" value="<?php echo $sua[2];?>"
                                name="emailup">
                            <div class="nk-gap"></div>
                            <h6>Điện Thoại</h6>
                            <input type="text" class="form-control" placeholder="Điện Thoại"
                                value="<?php echo $sua[3];?>" name="dtup">
                            <div class="nk-gap"></div>
                            <h6>Giới Tính</h6>
                            <label class="form-check-label">
                                <?php 
                            if($sua[5]==true){ 
                            ?>
                                <input type="radio" class="" name="gtup" checked value="1"> Nam

                                <input type="radio" class="" name="gtup" value="0"> Nữ
                                <?php
                                 }else{
                                 ?>
                                <input type="radio" class="" name="gtup" value="1"> Nam

                                <input type="radio" class="" name="gtup" checked value="0"> Nữ
                                <?php
                                 }?>
                            </label>
                            <div class="nk-gap"></div>
                            <button class="nk-btn link-effect-4 float-right" name="updateaccount">Cập Nhật</button>
                            <?php } 
                        }?>
                        </form>
                        <?php
                        if(isset($_POST['updateaccount'])){
                            $hovaten = $_POST['htup'];
                            $emailup = $_POST['emailup'];
                            $dienthoaiup = $_POST['dtup'];
                            $gioitinhup= $_POST['gtup'];
                            $sql = "UPDATE account SET Email='$emailup',DienThoai='$dienthoaiup',HovaTen='$hovaten',GioiTinh='$gioitinhup' WHERE Username='$usm'";
                            $query = mysqli_query($connect,$sql);
                            $result= mysqli_num_rows($query);
                            echo "Cập nhật thành công !!";
                            header("Location: http://localhost/NghiaTrangOnline1/info.php?nameus=$usm");
                        }
                        ?>
                    </div>
                    <div class="nk-gap-4"></div>
                </div>
            </div>
            <div class="nk-gap-4"></div>
            <div class="nk-gap-3"></div>
        </div>

        <footer class="nk-footer nk-footer-parallax nk-footer-parallax-opacity">
            <img class="nk-footer-top-corner" src="assets/images/footer-corner.png" alt="">
            <div class="container">
                <div class="nk-gap-2"></div>
                <div class="nk-footer-logos">

                </div>
                <div class="nk-gap"></div>
                <p> &copy; 2020 Design by nK Group Inc. </p>
                <div class="nk-gap-4"></div>
            </div>
        </footer>
        <!-- END: Footer -->
    </div>

    <div class="nk-share-buttons nk-share-buttons-left d-none d-md-flex">
        <ul>
            <li>
                <span class="nk-share-icon" title="Share page on Facebook" data-share="facebook">
                    <span class="icon fa fa-facebook"></span>
                </span>
                <span class="nk-share-name">Facebook</span>
            </li>
            <li>
                <span class="nk-share-icon" title="Share page on Twitter" data-share="twitter">
                    <span class="icon fa fa-twitter"></span>
                </span>
                <span class="nk-share-name">Twitter</span>
            </li>



        </ul>
    </div>
    <!--
    START: Side Buttons
        .nk-side-buttons-visible
-->
    <div class="nk-side-buttons nk-side-buttons-visible">
        <ul>

            <li>
                <span class="nk-btn nk-btn-lg nk-btn-icon nk-bg-audio-toggle">
                    <span class="icon">
                        <span class="ion-android-volume-up nk-bg-audio-pause-icon"></span>
                        <span class="ion-android-volume-off nk-bg-audio-play-icon"></span>
                    </span>
                </span>
            </li>
            <li class="nk-scroll-top">
                <span class="nk-btn nk-btn-lg nk-btn-icon">
                    <span class="icon ion-ios-arrow-up"></span>
                </span>
            </li>
        </ul>
    </div>

    <div class="nk-search">
        <div class="container">
            <form action="#">
                <fieldset class="form-group nk-search-field">
                    <input type="text" class="form-control" id="searchInput" placeholder="Search..." name="s">
                    <label for="searchInput"><i class="ion-ios-search"></i></label>
                </fieldset>
            </form>
        </div>
    </div>


    <div class="nk-sign-form">
        <div class="nk-gap-5"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 offset-lg-4 col-md-6 offset-md-3">
                    <div class="nk-sign-form-container">
                        <div class="nk-sign-form-toggle h3">
                            <a href="#" class="nk-sign-form-login-toggle active">Đăng Nhập</a>
                            <a href="#" class="nk-sign-form-register-toggle">Đăng Ký</a>
                        </div>
                        <div class="nk-gap-2"></div>

                        <form class="nk-sign-form-login active" method="POST">
                            <input class="form-control" type="text" placeholder="Username " name="username">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="password" placeholder="Password" name="password">
                            <div class="nk-gap-2"></div>
                            <div class="form-check float-left">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"> Remember Me </label>
                            </div>
                            <button class="nk-btn nk-btn-color-white link-effect-4 float-right" name="login">Đăng
                                Nhập</button>
                            <div class="clearfix"></div>
                            <div class="nk-gap-1"></div>
                            <a class="nk-sign-form-lost-toggle float-right" href="#">Quên Mật Khẩu?</a>
                        </form>

                        <form class="nk-sign-form-lost" action="#">
                            <input class="form-control" type="text" placeholder="Username or Email">
                            <div class="nk-gap-2"></div>
                            <button class="nk-btn nk-btn-color-white link-effect-4 float-right">Đổi Mật Khẩu</button>
                        </form>

                        <form class="nk-sign-form-register" method="POST">
                            <input class="form-control" type="text" placeholder="Username" name="username">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="password" placeholder="Mật Khẩu" name="password">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="email" placeholder="Email" name="email">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="text" placeholder="Họ Và Tên" name="hovaten">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="tel" placeholder="Điện Thoại" name="dienthoai"
                                maxlength="10">
                            <div class="nk-gap-2"></div>

                            <button class="nk-btn nk-btn-color-white link-effect-4 float-right" name="register">Đăng
                                Ký</button>

                        </form>
                        <?php 
                         if(isset($_POST['register'])){
							$username= $_POST['username'];
							$matkhau =$_POST['password'];
                            $email= $_POST['email'];
                            $dta = $_POST['dienthoai'];
                           $hvt =$_POST['hovaten'];
                    		if($username ==""|| $matkhau==""|| $email == "" || $dta =="" ||  $hvt==""){
								echo "Vui lòng nhập đầy đủ thông tin";
                            }  else  {
								
								$sql = ("INSERT INTO account(Username, Password, Email, DienThoai,HovaTen) VALUES ('$username','$matkhau','$email','$dta',' $hvt')");
								$query = mysqli_query($connect,$sql);
                                   echo " Đăng Ký Thành Công!";                   
                                      header("Location: http://localhost/NghiaTrangOnline1/trangchu.php");

										}									   
                                    }	
                                
					
                            ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="nk-gap-5"></div>
    </div>
    <!-- END: Sign Form -->
    <!-- START: Scripts -->
    <!-- Object Fit Polyfill -->
    <script src="assets/vendor/object-fit-images/dist/ofi.min.js"></script>
    <!-- GSAP -->
    <script src="assets/vendor/gsap/dist/gsap.min.js"></script>
    <script src="assets/vendor/gsap/dist/ScrollToPlugin.min.js"></script>
    <!-- Popper -->
    <script src="assets/vendor/popper.js/dist/umd/popper.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/vendor/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Sticky Kit -->
    <script src="assets/vendor/sticky-kit/dist/sticky-kit.min.js"></script>
    <!-- Jarallax -->
    <script src="assets/vendor/jarallax/dist/jarallax.min.js"></script>
    <script src="assets/vendor/jarallax/dist/jarallax-video.min.js"></script>
    <!-- imagesLoaded -->
    <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
    <!-- Flickity -->
    <script src="assets/vendor/flickity/dist/flickity.pkgd.min.js"></script>
    <!-- Isotope -->
    <script src="assets/vendor/isotope-layout/dist/isotope.pkgd.min.js"></script>
    <!-- Photoswipe -->
    <script src="assets/vendor/photoswipe/dist/photoswipe.min.js"></script>
    <script src="assets/vendor/photoswipe/dist/photoswipe-ui-default.min.js"></script>
    <!-- Typed.js -->
    <script src="assets/vendor/typed.js/lib/typed.min.js"></script>
    <!-- Jquery Validation -->
    <script src="assets/vendor/jquery-validation/dist/jquery.validate.min.js"></script>
    <!-- Jquery Countdown + Moment -->
    <script src="assets/vendor/jquery-countdown/dist/jquery.countdown.min.js"></script>
    <script src="assets/vendor/moment/min/moment.min.js"></script>
    <script src="assets/vendor/moment-timezone/builds/moment-timezone-with-data.min.js"></script>
    <!-- Hammer.js -->
    <script src="assets/vendor/hammerjs/hammer.min.js"></script>
    <!-- NanoSroller -->
    <script src="assets/vendor/nanoscroller/bin/javascripts/jquery.nanoscroller.js"></script>
    <!-- SoundManager2 -->
    <script src="assets/vendor/soundmanager2/script/soundmanager2-nodebug-jsmin.js"></script>
    <!-- DateTimePicker -->
    <script src="assets/vendor/jquery-datetimepicker/build/jquery.datetimepicker.full.min.js"></script>
    <!-- Revolution Slider -->
    <script src="assets/vendor/revolution/js/jquery.themepunch.tools.min.js"></script>
    <script src="assets/vendor/revolution/js/jquery.themepunch.revolution.min.js"></script>
    <script src="assets/vendor/revolution/js/extensions/revolution.extension.video.min.js"></script>
    <script src="assets/vendor/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
    <script src="assets/vendor/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
    <!-- Keymaster -->
    <script src="assets/vendor/keymaster/keymaster.js"></script>
    <!-- Summernote -->
    <script src="assets/vendor/summernote/dist/summernote-bs4.min.js"></script>
    <!-- GODLIKE -->
    <script src="assets/js/godlike.min.js"></script>
    <script src="assets/js/godlike-init.js"></script>
    <!-- END: Scripts -->
</body>

</html>