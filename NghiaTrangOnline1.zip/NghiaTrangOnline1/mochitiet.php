<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php
   include "ConnectDatabase.php";
$idmo=$_GET['ID'];
                   $sql = "SELECT *FROM mo where ID='$idmo'";
               $query = mysqli_query($connect,$sql);
               $result= mysqli_num_rows($query);
               if($query){
                   while ( $data =mysqli_fetch_array($query) ) {
               
   
   ?>
    <title>Nghĩa Trang Online | Mộ Online <?php echo $data[2];?></title>
    <?php
        }
    }    
    ?>
    <link rel="icon" type="image/png" href="assets/images/icon.png">
    <!-- START: Styles -->
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300i,400,400i,700%7cMarcellus+SC"
        rel="stylesheet">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/dist/css/bootstrap.min.css">
    <!-- FontAwesome -->
    <script defer src="assets/vendor/fontawesome-free/js/all.js"></script>
    <script defer src="assets/vendor/fontawesome-free/js/v4-shims.js"></script>
    <!-- IonIcons -->
    <link rel="stylesheet" href="assets/vendor/ionicons/css/ionicons.min.css">
    <!-- Revolution Slider -->
    <link rel="stylesheet" href="assets/vendor/revolution/css/settings.css">
    <link rel="stylesheet" href="assets/vendor/revolution/css/layers.css">
    <link rel="stylesheet" href="assets/vendor/revolution/css/navigation.css">
    <!-- Flickity -->
    <link rel="stylesheet" href="assets/vendor/flickity/dist/flickity.min.css">
    <!-- Photoswipe -->
    <link rel="stylesheet" href="assets/vendor/photoswipe/dist/photoswipe.css">
    <link rel="stylesheet" href="assets/vendor/photoswipe/dist/default-skin/default-skin.css">
    <!-- DateTimePicker -->
    <link rel="stylesheet" href="assets/vendor/jquery-datetimepicker/build/jquery.datetimepicker.min.css">
    <!-- Summernote -->
    <link rel="stylesheet" href="assets/vendor/summernote/dist/summernote-bs4.css">
    <!-- GODLIKE -->
    <link rel="stylesheet" href="assets/css/godlike.css">
    <!-- Custom Styles -->
    <link rel="stylesheet" href="assets/css/custom.css">
    <!-- END: Styles -->
    <!-- jQuery -->
    <script src="assets/vendor/jquery/dist/jquery.min.js"></script>
</head>

<body style="background-image: url('assets/images/nentrang.jpg');">

    <div class="nk-preloader">

        <div class="nk-preloader-bg" style="background-color: #000;" data-close-frames="23" data-close-speed="1.2"
            data-close-sprites="./assets/images/preloader-bg.png" data-open-frames="23" data-open-speed="1.2"
            data-open-sprites="./assets/images/preloader-bg-bw.png">
        </div>
        <div class="nk-preloader-content">
            <div>

                <!-- <img class="nk-img" src="assets/images/logo.svg" alt="GodLike - Gaming Bootstrap 4 Template" width="170"> -->
                <div class="nk-preloader-animation"></div>
            </div>
        </div>
        <div class="nk-preloader-skip">Skip</div>
    </div>
<!-- 
    <div class="nk-page-background op-5" data-video="https://youtu.be/UkeDo1LhUqQ" data-video-loop="true"
        data-video-mute="true" data-video-volume="0" data-video-start-time="0" data-video-end-time="0"
        data-video-pause-on-page-leave="true" style="background-image: url('assets/images/page-background.jpg');"></div> -->

    <div class="nk-page-background-audio d-none" data-audio="assets/mp3/purpleplanetmusic-desolation.mp3"
        data-audio-volume="100" data-audio-autoplay="true" data-audio-loop="true" data-audio-pause-on-page-leave="true">
    </div>

    <div class="nk-page-border">
        <div class="nk-page-border-t"></div>
        <div class="nk-page-border-r"></div>
        <div class="nk-page-border-b"></div>
        <div class="nk-page-border-l"></div>
    </div>

    <header class="nk-header nk-header-opaque">

        <div class="nk-contacts-top">
            <div class="container">
                <div class="nk-contacts-left">
                    <div class="nk-navbar">

                    </div>
                </div>
                <div class="nk-contacts-right">
                    <div class="nk-navbar">
                        <ul class="nk-nav">
                            <li><a href="" target="_blank"><span class="ion-social-twitter"></span></a></li>
                            <li><a href="" target="_blank"><span class="ion-social-dribbble-outline"></span></a></li>
                            <li><a href="#"><span class="ion-social-instagram-outline"></span></a></li>
                            <li><a href="#"><span class="ion-social-pinterest"></span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <nav class="nk-navbar nk-navbar-top nk-navbar-sticky nk-navbar-transparent nk-navbar-autohide">
            <div class="container">
                <div class="nk-nav-table">
                    <a href="trangchu.php" class="nk-nav-logo">
                        <!-- <img src="assets/images/logo.svg" alt="" width="90"> -->
                        Vĩnh Hằng
                    </a>
                    <ul class="nk-nav nk-nav-right d-none d-lg-block" data-nav-mobile="#nk-nav-mobile">
                        <li class=" ">
                            <a href="trangchu.php"> Trang chủ</a>

                        </li>
                        <li class="  nk-drop-item">
                            <a href=""> Khu Vườn</a>
                            <ul class="dropdown">
                                <li class="  nk-drop-item">
                                    <a href=""> Coming Soon</a>
                                    <ul class="dropdown">
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="  nk-drop-item">
                                    <a href=""> Coming Soon</a>
                                    <ul class="dropdown">
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon </a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>

                            </ul>
                        </li>

                        <li class="  nk-drop-item">
                            <a href=""> Cửa Hàng</a>
                            <ul class="dropdown">
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                            </ul>
                        </li>

                    </ul>
                    <ul class="nk-nav nk-nav-right nk-nav-icons">
                        <li class="single-icon d-lg-none">
                            <a href="#" class="no-link-effect" data-nav-toggle="#nk-nav-mobile">
                                <span class="nk-icon-burger">
                                    <span class="nk-t-1"></span>
                                    <span class="nk-t-2"></span>
                                    <span class="nk-t-3"></span>
                                </span>
                            </a>
                        </li>
                        <?php
                        session_start();
                       if(isset($_POST['login'])){
                        $username= $_POST['username'];
                        $matkhau =$_POST['password'];
                     
                        if($username ==""|| $matkhau==""){
                            echo "Vui lòng nhập đầy đủ thông tin";
                        }  else  {
                            $sql = "SELECT * FROM account";
                            $query = mysqli_query($connect,$sql);
                            $result= mysqli_num_rows($query);
                            if($result>0 ){  
                                while ( $data =mysqli_fetch_assoc($query) ) {
                                    $usernameB= $data['Username'];
                                    $matkhauA =$data['Password'];	
                                                    
                                        if($username == $usernameB && $matkhau == $matkhauA ){	
                                                echo "Đăng Nhập Thành Công";
                                              $_SESSION["username"] = $username;    
                                             header("Location: http://localhost/NghiaTrangOnline1/trangchu.php");
                                                                                         
                                    }else{										
                                        echo "Đăng Nhập Thất Bại";				
                                    }										   
                            }
                            mysqli_free_result($query);	 	
                        }
                        }
                        mysqli_close($connect);
                                    }	
                                   								   
                              if(  !isset( $_SESSION["username"])){
                      ?>
                        <li class="single-icon">
                            <a href="#" class="nk-sign-toggle no-link-effect" id="LGLU">
                                <span class="nk-icon-toggle">
                                    <span class="nk-icon-toggle-front">
                                        <span class="fa fa-sign-in"></span>
                                    </span>
                                    <span class="nk-icon-toggle-back">
                                        <span class="nk-icon-close"></span>
                                    </span>
                                </span>
                            </a>
                        </li>
                        <?php
                         }  else{

                         
                        
                        ?>
                        <form method="post">
                            <li class="single-icon">

                                <span style="font-size: 15px; word-wrap: break-word;">Xin chào,<br>
                                    <a href="account.php?nameus=<?php echo $_SESSION['username'];?>"><?php echo $_SESSION['username'];?> </a>
                                    <button name="logout" class="">
                                        <i class="fa fa-sign-in"></i>
                                    </button>
                                </span>

                            </li>
                        </form>
                        <?php } 
                         if(isset($_POST['logout'])){                          
                            session_unset();
                            header("Location: http://localhost/NghiaTrangOnline1/trangchu.php");
                            
                        }
                        ?>

                    </ul>
                </div>
            </div>
        </nav>

    </header>



    <div id="nk-nav-mobile" class="nk-navbar nk-navbar-side nk-navbar-left-side nk-navbar-overlay-content d-lg-none">
        <div class="nano">
            <div class="nano-content">
                <a href="trangchu.php" class="nk-nav-logo">
                    Vĩnh Hằng
                    <!-- <img src="assets/images/icon.png" alt="" width="90"> -->
                </a>
                <div class="nk-navbar-mobile-content">
                    <ul class="nk-nav">

                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-main">
        <div class="container">
            <div class="nk-gap-4"></div>
            <div class="nk-store-product" id="mool_load_chinh">
                <div class="row xl-gap vertical-gap align-items-center">
                    <!-- Bài Vị-->
                    <input type="hidden" value="<?php echo $_GET['Dao1'];?>" id="setdao" name="setdao">
                    <div class="moll">
                        <?php                    
                        $idmo=$_GET['ID'];
                                        $sql = "SELECT *FROM mo where ID='$idmo'";
                                    $query = mysqli_query($connect,$sql);
                                    $result= mysqli_num_rows($query);
                                    if($query){
                                        while ( $data =mysqli_fetch_array($query) ) {                        
                        ?>
                        <div class="nk-gap-4"></div>
                        <img src="assets/images/biabaivi.png" alt="" srcset="" width="300" height="400">
                        <!-- <img src="<?php if($data[10]==""){ echo "";}else{ echo "assets/images/".$data[11];} ?>" alt="" class="moll_hinh" id="hinhbia"> -->
                        <p class="moll_thanh" id="tenthanh"><?php
                                $cacthanhnam= array('Phêrô', 'Anrê', 'Gioan Baotixita', 'Gioan', 'Phaolô', 'Giuđa', 'Philipphê', 'MátThêu', 'Giacôbê',
                                'Tôma', 'Mátthia', 'Nathanaen');
                                if($data[12] == "254264644"){
                                    echo $data[1] ;
                                }else{
                                    foreach($cacthanhnam as $key => $value):
                                        if($data[1] == $value){
                                            echo "Ông : ".$data[1] ;
                                        }else{
                                            echo " ";
                                        }
                                    endforeach;
                                    $cacthanhnu= array('Anna', 'Maria', 'Têrêsa', 'Lucia', 'INê', 'FausTiNa', 'MôNiCa', 'Maria Mađalêna',
                                    'Catarina De Siena');
                                    foreach($cacthanhnu as $key => $value):
                                        if($data[1] == $value){
                                            echo "Bà : ".$data[1] ;
                                        }else{ 
                                            echo " ";
                                        }
                                    endforeach;
                                }   
                        
                                ?></p>
                        <input type="hidden" value="<?php echo $data[1]; ?>" id="tenthanhan" name="tenthanhan">
                        <p class="moll_nk" id="tenngmat"><?php echo $data[2];?></p>
                        <p class="moll_qq">Quê Quán : <?php echo $data[6];?></p>
                        <p class="moll_nam"><?php
                            $ngaysinh = date("d/m/Y", strtotime($data[4])); 
                            $ngaymat = date("d/m/Y", strtotime($data[5])); 
                                if($data[4] != "0000-00-00" && $data[5] != "0000-00-00"){
                                echo $ngaysinh. " - " .$ngaymat ;
                                }else if($data[4]  == "0000-00-00" && $data[5] == "0000-00-00") {
                                echo " ? - ? ";
                                }else if($data[4] == "0000-00-00"){
                                echo " ? -  ".$ngaymat;
                                }else  if($data[5]== "0000-00-00"){
                            echo $ngaysinh." - ? ";
                                }
                    
                            ?></p>
                        <p class="moll_huongtho"><?php  
                        $nammat1= date("Y", strtotime($data[5]));
                        $namsinh1 =date("Y", strtotime($data[4])); 
                            $tongtuoi= $nammat1 - $namsinh1; 
                            if($data[4] != "0000-00-00" && $data[5] != "0000-00-00"){                  
                                if($tongtuoi <= 60){
                                    echo "Hưởng Dương: " .$tongtuoi;
                                }else if($tongtuoi >= 80){
                                echo " Thượng Thọ: " .$tongtuoi;
                                    }else {
                                echo " Hưởng Thọ: " .$tongtuoi;
                                } 
                            }else if($data[4]  == "0000-00-00" && $data[5] == "0000-00-00") {
                                    echo "?";
                            }else if($data[4] == "0000-00-00"){
                                    echo "?";
                            }else  if($data[5]== "0000-00-00"){
                                    echo "?";
                            }
                            ?> tuổi</p>
                        <p class="moll_lapmo" id="lapmo"><?php echo $data[7];?> lập mộ</p>
                        <?php
                        }
                        }?>


                    </div>
                    <div class="nk-gap-3"></div>

                </div>
                <div class="hiengle" id="mool_cn_chinh">
                    <table class="hinhvieng">
                        <tbody>
                            <tr>
                                <th id="qua"></th>
                                <th id="linhthieng"></th>
                                <th id="hoa"></th>
                            </tr>
                        </tbody>

                    </table>
                    <marquee class="load">
                        <i id="mool_load_cn"></i>
                        <div class="clear"></div>

                    </marquee>
                    <i id="amthanh" class="amthanh"></i>
                    <marquee class="caunguyen">
                        <i id="loicau_nguyen"></i>
                    </marquee>
                    <?php
                    $setdao =$_GET['Dao1'];
                    if($setdao === "Thiên Chúa"){
                    ?>
                    <b cn="4" class="nk-btn  nk-btn-bg-danger" id="dockinh"><img src="assets/images/book1243.gif"
                            width="30"> </b>
                    <?php
                            }else{?>
                    <b cn="4" class="nk-btn  nk-btn-bg-danger" id="dockinh"><img src="assets/images/gomo.gif"
                            width="30"> </b>
                    <?php
                            }
                            ?>
                    <b cn="1" class="nk-btn  nk-btn-bg-danger"><img src="assets/images/LuHuong.gif" width="20"
                            height="20"></b>
                    <b cn="2" class="nk-btn  nk-btn-bg-danger"><img src="assets/images/ghq.png" width="20"
                            height="20"></b>
                    <b cn="3" class="nk-btn  nk-btn-bg-danger">💐</b>
                    <a href="loginedit.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $_GET['Dao1'];?>&ID=<?php echo $_GET['ID'];?>"
                        class="nk-btn  nk-btn-bg-danger "><i class="far fa-edit"></i></a>
                </div>

                <div class="nk-gap-3"></div>

            </div>

        </div>
        <script>
        $("#mool_load_chinh b").click(function() {
            if ($(this).attr("cn") == "1") {
                mool_cn_load_f("Xin thắp nén hương trầm - ấm lòng người dưới mộ !");
                mool_cn_load_e_time(7000);
                document.getElementById("linhthieng").innerHTML =
                    "<img src='assets/images/huong.png' alt='' class='huongqua'>";

            } else if ($(this).attr("cn") == "2") {
                mool_cn_load_f("Xin thành tâm dâng lễ, thành tâm kính viến !");
                mool_cn_load_e_time(7000);
                document.getElementById("qua").innerHTML =
                    "<img src='assets/images/qua.png' alt='' class='huongqua'>";
            } else if ($(this).attr("cn") == "3") {
                mool_cn_load_f("Xin dâng những đóa hoa, thành tâm cầu linh hồn an nghỉ !");
                mool_cn_load_e_time(7000);
                document.getElementById("hoa").innerHTML =
                    "<img src='assets/images/hoa1.png' alt='' class='huongqua'>";
            }

            function mool_cn_load_f(mool_text_load_i) {
                $("#mool_cn_chinh b").fadeOut(10);
                setTimeout(function() {
                    $("#mool_cn_chinh #mool_load_cn").text(mool_text_load_i);
                    $("#mool_cn_chinh #mool_load_cn").fadeIn(500);
                }, 500);
            }

            function mool_cn_load_e_time(e_time) {
                setTimeout(function() {
                    mool_cn_load_e();
                }, e_time);
            }

            function mool_cn_load_e() {
                $("#mool_cn_chinh #mool_load_cn").fadeOut(300);
                setTimeout(function() {
                    $("#mool_cn_chinh b").fadeIn(500);
                }, 700);
            }
            $(this).remove();
        });

        $("#dockinh").click(function() {
            var setdaao = document.getElementById("setdao").value;
            if ($(this).attr("cn") == "4" && setdaao == "Thiên Chúa") {
                var dockinh = setTimeout(() => {
                    var tenthanh = document.getElementById("tenthanhan").value;
                    var loicau = document.getElementById("loicau_nguyen").innerHTML =
                        "Chúng con cậy vì Danh Chúa Nhân Từ xin cho linh hồn <i class='batbuoc'>" +
                        tenthanh +
                        "</i>  được lên chốn nghỉ ngơi. Hằng xem thấy mặt Đức Chúa Trời sáng láng vui vẻ vô cùng. Amen";
                    var amthanh = document.getElementById("amthanh").innerHTML =
                        " <audio  autoplay class='atui' > <source src = 'assets/mp3/kinhChua.mp3' type = 'audio/ogg' > </audio>";

                }, 5000);

                function clearAlert() {
                    clearTimeout(dockinh);
                }
            } else {
                var dockinh = setTimeout(() => {
                    var loicau = document.getElementById("loicau_nguyen").innerHTML =
                        "Nam-mô Tây phương Cực lạc thế giới tam thập lục vạn ức, nhứt thập nhứt vạn, cửu thiên ngũ bá đồng danh đồng hiệu đại từ đại bi tiếp dẫn vong linh A-Di-Đà Phật";
                    var amthanh = document.getElementById("amthanh").innerHTML =
                        "   <audio  autoplay class='atui' > <source src = 'assets/mp3/np1.mp3'  type = 'audio/ogg' > </audio>";

                }, 5000);

                function clearAlert() {
                    clearTimeout(dockinh);
                }
            }

        });
        </script>
        <div class="nk-gap-3"></div>
        <div class="">
            <?php
                            $dao=$_GET['Dao1'];
                            $makm=$_GET['KMID'];
                            $sql = "SELECT *FROM mo where Dao='$dao' and MaKM='$makm'";
                                    $query = mysqli_query($connect,$sql);
                                    $result= mysqli_num_rows($query);
                                    if($query){
                                        while ( $mo =mysqli_fetch_array($query) ) {
                                            if($_GET['ID']!= $mo[0]){
                                            if($mo[10] == "4.jpg"){
                            ?>
            <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                <div class="nk-image-box-3 nk-no-effect hover">
                    <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                        class="nk-image-box-link"></a>
                    <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                        id="hinhshow">
                    <p class="molc"><?php echo $mo[2]; ?></p>
                    <p class="yearlc" id="year" style="color: white;">
                        <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                </div>
            </div>
            <?php }else if($mo[10] == "1.jpg"){
                ?>
            <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                <div class="nk-image-box-3 nk-no-effect hover">
                    <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                        class="nk-image-box-link"></a>
                    <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                        id="hinhshow">
                    <p class="molc"><?php echo $mo[2]; ?></p>
                    <p class="yearlc" id="year">
                        <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                </div>
            </div>
            <?php  }else if($mo[10] == "8.jpg"){
                        ?>
            <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                <div class="nk-image-box-3 nk-no-effect hover">
                    <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                        class="nk-image-box-link"></a>
                    <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                        id="hinhshow">
                    <p class="molc" style="bottom: 75px;"><?php echo $mo[2]; ?></p>
                    <p class="yearlc" id="year" style="color: white;">
                        <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                </div>
            </div>
            <?php  }else if($mo[10]=="3.jpg"){
                            ?>
            <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                <div class="nk-image-box-3 nk-no-effect hover">
                    <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                        class="nk-image-box-link"></a>
                    <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                        id="hinhshow">
                    <p class="molc" style="bottom: 125px; "><?php echo $mo[2]; ?></p>
                    <p class="yearlc" id="year" style="color: white; bottom:85px;">
                        <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                </div>
            </div>
            <?php  } else if($mo[10]=="5.jpg"){
                    ?>
            <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                <div class="nk-image-box-3 nk-no-effect hover">
                    <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                        class="nk-image-box-link"></a>
                    <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                        id="hinhshow">
                    <p class="molc" style="bottom: 95px; left:40px;"><?php echo $mo[2]; ?></p>
                    <p class="yearlc" id="year" style="color: white; bottom:95px;">
                        <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                </div>
            </div>

            <?php }  else if($mo[10] =="6.jpg"){
                    ?>
            <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                <div class="nk-image-box-3 nk-no-effect hover">
                    <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                        class="nk-image-box-link"></a>
                    <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                        id="hinhshow">
                    <p class="molc" style="bottom: 155px; left: 40px;"><?php echo $mo[2]; ?></p>
                    <p class="yearlc" id="year" style="color: white; bottom:90px;">
                        <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                </div>
            </div>

            <?php  }else if($mo[10]=="7.jpg"){
                    ?>
            <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                <div class="nk-image-box-3 nk-no-effect hover">
                    <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                        class="nk-image-box-link"></a>
                    <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                        id="hinhshow">
                    <p class="molc" style="bottom: 145px; left: 40px;"><?php echo $mo[2]; ?></p>
                    <p class="yearlc" id="year" style="color: white; bottom:105px;">
                        <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                </div>
            </div>
            <?php
            }    
             }                         
                                }
                             }
                            ?>
        </div>
        <div class="nk-gap-4"></div>
        <footer class="nk-footer nk-footer-parallax nk-footer-parallax-opacity">
            <img class="nk-footer-top-corner" src="assets/images/footer-corner.png" alt="">
            <div class="container">
                <div class="nk-gap-2"></div>
                <div class="nk-footer-logos">
                    <a href="" target="_blank"><img class="nk-img" src="assets/images/footer-logo-godlike.png" alt=""
                            width="120"></a>
                    <a href="" target="_blank"><img class="nk-img" src="assets/images/footer-logo-yp3.png" alt=""
                            width="120"></a>
                    <a href="" target="_blank"><img class="nk-img" src="assets/images/footer-logo-nk-team.png" alt=""
                            width="150"></a>
                    <a href="" target="_blank"><img class="nk-img" src="assets/images/footer-logo-pegi-18.png" alt=""
                            width="46"></a>
                    <a href="" target="_blank"><img class="nk-img" src="assets/images/footer-logo-18-restricted.png"
                            alt="" width="160"></a>
                </div>
                <div class="nk-gap"></div>
                <p> &copy; 2020 Design by nK Group Inc. </p>

                <div class="nk-gap-4"></div>
            </div>
        </footer>
        <!-- END: Footer -->
    </div>

    <div class="nk-share-buttons nk-share-buttons-left d-none d-md-flex">
        <ul>
            <li>
                <span class="nk-share-icon" title="Share page on Facebook" data-share="facebook">
                    <span class="icon fa fa-facebook"></span>
                </span>
                <span class="nk-share-name">Facebook</span>
            </li>
            <li>
                <span class="nk-share-icon" title="Share page on Twitter" data-share="twitter">
                    <span class="icon fa fa-twitter"></span>
                </span>
                <span class="nk-share-name">Twitter</span>
            </li>


        </ul>
    </div>

    <div class="nk-side-buttons nk-side-buttons-visible">
        <ul>
            <li>

            </li>
            <li>
                <span class="nk-btn nk-btn-lg nk-btn-icon nk-bg-audio-toggle">
                    <span class="icon">
                        <span class="ion-android-volume-up nk-bg-audio-pause-icon"></span>
                        <span class="ion-android-volume-off nk-bg-audio-play-icon"></span>
                    </span>
                </span>
            </li>
            <li class="nk-scroll-top">
                <span class="nk-btn nk-btn-lg nk-btn-icon">
                    <span class="icon ion-ios-arrow-up"></span>
                </span>
            </li>
        </ul>
    </div>

    <div class="nk-search">
        <div class="container">
            <form action="#">
                <fieldset class="form-group nk-search-field">
                    <input type="text" class="form-control" id="searchInput" placeholder="Search..." name="s">
                    <label for="searchInput"><i class="ion-ios-search"></i></label>
                </fieldset>
            </form>
        </div>
    </div>

    <div class="nk-sign-form">
        <div class="nk-gap-5"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 offset-lg-4 col-md-6 offset-md-3">
                    <div class="nk-sign-form-container">
                        <div class="nk-sign-form-toggle h3">
                            <a href="#" class="nk-sign-form-login-toggle active">Đăng Nhập</a>
                            <a href="#" class="nk-sign-form-register-toggle">Đăng Ký</a>
                        </div>
                        <div class="nk-gap-2"></div>

                        <form class="nk-sign-form-login active" action="#">
                            <input class="form-control" type="text" placeholder="Username or Email">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="password" placeholder="Password">
                            <div class="nk-gap-2"></div>
                            <div class="form-check float-left">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"> Remember Me </label>
                            </div>
                            <button class="nk-btn nk-btn-color-white link-effect-4 float-right">Đăng Nhập</button>
                            <div class="clearfix"></div>
                            <div class="nk-gap-1"></div>
                            <a class="nk-sign-form-lost-toggle float-right" href="#">Quên Mật Khẩu?</a>
                        </form>

                        <form class="nk-sign-form-lost" action="#">
                            <input class="form-control" type="text" placeholder="Username or Email">
                            <div class="nk-gap-2"></div>
                            <button class="nk-btn nk-btn-color-white link-effect-4 float-right">Đổi Mật Khẩu</button>
                        </form>

                        <form class="nk-sign-form-register" action="#">
                            <input class="form-control" type="text" placeholder="Username">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="password" placeholder="Mật Khẩu">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="email" placeholder="Email">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="text" placeholder="Họ Và Tên">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="tel" placeholder="Điện Thoại">
                            <div class="nk-gap-2"></div>

                            <button class="nk-btn nk-btn-color-white link-effect-4 float-right">Đăng Ký</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
        <div class="nk-gap-5"></div>
    </div>
    <!-- END: Sign Form -->
    <!-- START: Scripts -->
    <!-- Object Fit Polyfill -->
    <script src="assets/vendor/object-fit-images/dist/ofi.min.js"></script>
    <!-- GSAP -->
    <script src="assets/vendor/gsap/dist/gsap.min.js"></script>
    <script src="assets/vendor/gsap/dist/ScrollToPlugin.min.js"></script>
    <!-- Popper -->
    <script src="assets/vendor/popper.js/dist/umd/popper.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/vendor/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Sticky Kit -->
    <script src="assets/vendor/sticky-kit/dist/sticky-kit.min.js"></script>
    <!-- Jarallax -->
    <script src="assets/vendor/jarallax/dist/jarallax.min.js"></script>
    <script src="assets/vendor/jarallax/dist/jarallax-video.min.js"></script>
    <!-- imagesLoaded -->
    <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
    <!-- Flickity -->
    <script src="assets/vendor/flickity/dist/flickity.pkgd.min.js"></script>
    <!-- Isotope -->
    <script src="assets/vendor/isotope-layout/dist/isotope.pkgd.min.js"></script>
    <!-- Photoswipe -->
    <script src="assets/vendor/photoswipe/dist/photoswipe.min.js"></script>
    <script src="assets/vendor/photoswipe/dist/photoswipe-ui-default.min.js"></script>
    <!-- Typed.js -->
    <script src="assets/vendor/typed.js/lib/typed.min.js"></script>
    <!-- Jquery Validation -->
    <script src="assets/vendor/jquery-validation/dist/jquery.validate.min.js"></script>
    <!-- Jquery Countdown + Moment -->
    <script src="assets/vendor/jquery-countdown/dist/jquery.countdown.min.js"></script>
    <script src="assets/vendor/moment/min/moment.min.js"></script>
    <script src="assets/vendor/moment-timezone/builds/moment-timezone-with-data.min.js"></script>
    <!-- Hammer.js -->
    <script src="assets/vendor/hammerjs/hammer.min.js"></script>
    <!-- NanoSroller -->
    <script src="assets/vendor/nanoscroller/bin/javascripts/jquery.nanoscroller.js"></script>
    <!-- SoundManager2 -->
    <script src="assets/vendor/soundmanager2/script/soundmanager2-nodebug-jsmin.js"></script>
    <!-- DateTimePicker -->
    <script src="assets/vendor/jquery-datetimepicker/build/jquery.datetimepicker.full.min.js"></script>
    <!-- Revolution Slider -->
    <script src="assets/vendor/revolution/js/jquery.themepunch.tools.min.js"></script>
    <script src="assets/vendor/revolution/js/jquery.themepunch.revolution.min.js"></script>
    <script src="assets/vendor/revolution/js/extensions/revolution.extension.video.min.js"></script>
    <script src="assets/vendor/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
    <script src="assets/vendor/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
    <!-- Keymaster -->
    <script src="assets/vendor/keymaster/keymaster.js"></script>
    <!-- Summernote -->
    <script src="assets/vendor/summernote/dist/summernote-bs4.min.js"></script>
    <!-- GODLIKE -->
    <script src="assets/js/godlike.min.js"></script>
    <script src="assets/js/godlike-init.js"></script>
    <!-- END: Scripts -->
    <style>
    .moll {
        background-position: center center;
        margin: auto;
        height: 500px;
        overflow: hidden;
    }

    .moll_nk {
        color: white;
        font-size: 18px;
        text-transform: uppercase;
        bottom: 220px;
        text-shadow: 0 0 3px yellowgreen;
        background-position: center center;
        position: relative;
        text-align: center;
        word-wrap: break-word;
    }

    .moll_thanh {
        color: white;
        font-size: 18px;
        text-transform: uppercase;
        bottom: 190px;

        text-shadow: 0 0 3px red;
        background-position: center center;
        position: relative;
        text-align: center;
        word-wrap: break-word;
    }

    .moll_qq {
        color: white;
        font-size: 18px;
        text-align: center;
        bottom: 250px;
        position: relative;
    }

    .moll_nam {
        color: white;
        font-size: 18px;
        text-align: center;
        bottom: 280px;
        position: relative;
    }

    .moll_huongtho {
        color: white;
        font-size: 18px;
        text-align: center;
        bottom: 310px;
        position: relative;
    }

    .moll_lapmo {
        color: white;
        font-size: 12px;
        text-align: center;
        bottom: 320px;
        position: relative;
        font-style: italic;
        opacity: 0.5;
    }

    .moll_hinh {
        width: 20%;
        border-radius: 50%;
        text-align: center;
        right: 100px;
        position: relative;
    }

    .hiengle {
        background-position: center center;
        margin: auto;
        text-align: center;
        overflow: hidden;
    }

    .molc {
        position: relative;
        bottom: 100px;
        color: sienna;
        left: 20px;
    }

    .yearlc {
        position: relative;
        bottom: 80px;
        color: black;
        font-size: 12px;
        left: 45px;
    }

    .hinhmo {
        background-position: center center;
        margin: auto;
        text-align: center;
        overflow: hidden;
    }

    .hinhvieng {

        background-position: center center;
        margin: auto;
        padding-top: 96px;
        overflow: hidden;
    }

    .batbuoc {
        color: red;
    }
    </style>
    <script>
    var cacthanhnam = ['Phêrô', 'Anrê', 'Gioan Baotixita', 'Gioan', 'Phaolô', 'Giuđa', 'Philipphê', 'MátThêu',
        'Giacôbê',
        'Tôma', 'Mátthia', 'Nathanaen'
    ];
    var cacthanhnu = ['Anna', 'Maria', 'Têrêsa', 'Lucia', 'INê', 'FausTiNa', 'MôNiCa', 'Maria Mađalêna',
        'Catarina De Siena'
    ];
    var tenthanh = document.getElementById("tenthanh");
    var tenthanhbia = document.getElementById("tenthanhan").value;
    var tenmo = document.getElementById("tenngmat");
    var nglapmo = document.getElementById("lapmo");
    if (tenmo > 30) {
        nglapmo.style.bottom = "350";
    }

    if (tenthanhbia == null) {
        nglapmo.style.bottom = "290px";
    } else {
        nglapmo.style.bottom = "320px";
    }

    cacthanhnam.forEach(function(item, index, array) {
        if (tenthanhbia == item) {
            tenthanh.style.textShadow = "0 0 3px red";

        }
    });

    cacthanhnu.forEach(function(item, index, array) {
        if (tenthanhbia == item) {

            tenthanh.style.textShadow = "0 0 3px  #ff4da6";
        }
    });
    if (tenthanhbia == "") {
        nglapmo.style.bottom = "290px";
    }
    </script>
</body>

</html>