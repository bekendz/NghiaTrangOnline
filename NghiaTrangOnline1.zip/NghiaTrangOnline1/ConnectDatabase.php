<?php 
 ob_start(); 
//khai báo biến host
$hostName = 'localhost';
// khai báo biến username
$userName = 'root';
//khai báo biến password
$passWord = '';
// khai báo biến databaseName
$databaseName = 'nghiatrangonline1';
// khởi tạo kết nối
 $connect = new mysqli($hostName, $userName, $passWord, $databaseName);
//Kiểm tra kết nối
if ($connect->connect_error) {
    exit('Kết nối không thành công. chi tiết lỗi:' . $connect->connect_error);
    echo "<script>console.log('Kết nối không thành công. chi tiết lỗi:. $connect->connect_error)');</script>";
}else {
        // thành công
    echo "<script>console.log('Kết Nối Thành Công');</script>";

}



?>