<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php  
      include "ConnectDatabase.php";
     
    $idkm =  $_GET['KMID'];
    
    $dao =$_GET['Dao1'];
                    $sql = "SELECT *FROM khumo where MaKM='$idkm' and Dao='$dao'";
				$query = mysqli_query($connect,$sql);
                $result= mysqli_num_rows($query);
                if($query){
					while ( $data =mysqli_fetch_array($query) ) {
						
							?>
    <title>Nghĩa Trang Online | <?php echo $data[1];?></title>
    <?php } }?>
    <link rel="icon" type="image/png" href="assets/images/icon.png">
    <!-- START: Styles -->
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300i,400,400i,700%7cMarcellus+SC"
        rel="stylesheet">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/dist/css/bootstrap.min.css">
    <!-- FontAwesome -->
    <script defer src="assets/vendor/fontawesome-free/js/all.js"></script>
    <script defer src="assets/vendor/fontawesome-free/js/v4-shims.js"></script>
    <!-- IonIcons -->
    <link rel="stylesheet" href="assets/vendor/ionicons/css/ionicons.min.css">
    <!-- Revolution Slider -->
    <link rel="stylesheet" href="assets/vendor/revolution/css/settings.css">
    <link rel="stylesheet" href="assets/vendor/revolution/css/layers.css">
    <link rel="stylesheet" href="assets/vendor/revolution/css/navigation.css">
    <!-- Flickity -->
    <link rel="stylesheet" href="assets/vendor/flickity/dist/flickity.min.css">
    <!-- Photoswipe -->
    <link rel="stylesheet" href="assets/vendor/photoswipe/dist/photoswipe.css">
    <link rel="stylesheet" href="assets/vendor/photoswipe/dist/default-skin/default-skin.css">
    <!-- DateTimePicker -->
    <link rel="stylesheet" href="assets/vendor/jquery-datetimepicker/build/jquery.datetimepicker.min.css">
    <!-- Summernote -->
    <link rel="stylesheet" href="assets/vendor/summernote/dist/summernote-bs4.css">
    <!-- GODLIKE -->
    <link rel="stylesheet" href="assets/css/godlike.css">
    <!-- Custom Styles -->
    <link rel="stylesheet" href="assets/css/custom.css">
    <!-- END: Styles -->
    <!-- jQuery -->
    <script src="assets/vendor/jquery/dist/jquery.min.js"></script>
</head>

<body id="bodyuser">

    <div class="nk-preloader">

        <div class="nk-preloader-bg" style="background-color: #000;" data-close-frames="23" data-close-speed="1.2"
            data-close-sprites="./assets/images/preloader-bg.png" data-open-frames="23" data-open-speed="1.2"
            data-open-sprites="./assets/images/preloader-bg-bw.png">
        </div>
        <div class="nk-preloader-content">
            <div>
                <!-- <img class="nk-img" src="assets/images/logo.svg" alt="GodLike - Gaming Bootstrap 4 Template" width="170"> -->
                <div class="nk-preloader-animation"></div>
            </div>
        </div>
        <div class="nk-preloader-skip">Skip</div>
    </div>

    <div class="nk-page-background op-5" data-video="https://youtu.be/UkeDo1LhUqQ" data-video-loop="true"
        data-video-mute="true" data-video-volume="0" data-video-start-time="0" data-video-end-time="0"
        data-video-pause-on-page-leave="true" style="background-image: url('assets/images/page-background.jpg');"></div>

    <div class="nk-page-background-audio d-none" data-audio="assets/mp3/purpleplanetmusic-desolation.mp3"
        data-audio-volume="100" data-audio-autoplay="true" data-audio-loop="true" data-audio-pause-on-page-leave="true">
    </div>

    <div class="nk-page-border">
        <div class="nk-page-border-t"></div>
        <div class="nk-page-border-r"></div>
        <div class="nk-page-border-b"></div>
        <div class="nk-page-border-l"></div>
    </div>

    <header class="nk-header nk-header-opaque">

        <div class="nk-contacts-top">
            <div class="container">
                <div class="nk-contacts-left">
                    <div class="nk-navbar">

                    </div>
                </div>
                <div class="nk-contacts-right">
                    <div class="nk-navbar">
                        <ul class="nk-nav">
                            <li><a href="https://twitter.com/nkdevv" target="_blank"><span
                                        class="ion-social-twitter"></span></a></li>
                            <li><a href="https://dribbble.com/_nK" target="_blank"><span
                                        class="ion-social-dribbble-outline"></span></a></li>
                            <li><a href="#"><span class="ion-social-instagram-outline"></span></a></li>
                            <li><a href="#"><span class="ion-social-pinterest"></span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>


        <nav class="nk-navbar nk-navbar-top nk-navbar-sticky nk-navbar-transparent nk-navbar-autohide">
            <div class="container">
                <div class="nk-nav-table">
                    <a href="trangchu.php" class="nk-nav-logo">
                        <!-- <img src="assets/images/logo.svg" alt="" width="90"> -->
                        Vĩnh Hằng
                    </a>
                    <ul class="nk-nav nk-nav-right d-none d-lg-block" data-nav-mobile="#nk-nav-mobile">
                        <li class=" ">
                            <a href="trangchu.php"> Trang chủ</a>
                            <!-- <ul class="dropdown">
                                    <li class="  ">
                                        <a href="index.html"> Landing</a>
                                    </li>
                                    <li class="active  ">
                                        <a href="index-main.html"> Main</a>
                                    </li>
                                    <li class="  ">
                                        <a href="index-game-promo.html"> Game Promo</a>
                                    </li>
                                </ul> -->
                        </li>
                        <li class="  nk-drop-item">
                            <a href=""> Khu Vườn</a>
                            <ul class="dropdown">
                                <li class="  nk-drop-item">
                                    <a href=""> Coming Soon</a>
                                    <ul class="dropdown">
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="  nk-drop-item">
                                    <a href=""> Coming Soon</a>
                                    <ul class="dropdown">
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon </a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                        <li class="  ">
                                            <a href=""> Coming Soon</a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>

                            </ul>
                        </li>

                        <li class="  nk-drop-item">
                            <a href=""> Cửa Hàng</a>
                            <ul class="dropdown">
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                                <li class="  ">
                                    <a href=""> Coming Soon</a>
                                </li>
                            </ul>
                        </li>

                    </ul>
                    <ul class="nk-nav nk-nav-right nk-nav-icons">
                        <li class="single-icon d-lg-none">
                            <a href="#" class="no-link-effect" data-nav-toggle="#nk-nav-mobile">
                                <span class="nk-icon-burger">
                                    <span class="nk-t-1"></span>
                                    <span class="nk-t-2"></span>
                                    <span class="nk-t-3"></span>
                                </span>
                            </a>
                        </li>

                        <?php
                         session_start();
                       if(isset($_POST['login'])){
                        $username= $_POST['username'];
                        $matkhau =$_POST['password'];
                     
                        if($username ==""|| $matkhau==""){
                            echo "Vui lòng nhập đầy đủ thông tin";
                        }  else  {
                            $sql = "SELECT * FROM account";
                            $query = mysqli_query($connect,$sql);
                            $result= mysqli_num_rows($query);
                            if($result>0 ){  
                                while ( $data =mysqli_fetch_assoc($query) ) {
                                    $usernameB= $data['Username'];
                                    $matkhauA =$data['Password'];	
                                    $emailus =$data['Email'];
                                           ?>
                        < <?php if($username == $usernameB && $matkhau == $matkhauA ){	
                                                echo "Đăng Nhập Thành Công";
                                              $_SESSION["username"] = $username;    
                                              $_SESSION["emailg"] =   $emailus ;
                                             header("Location: http://localhost/NghiaTrangOnline1/trangchu.php");
                                                                                         
                                    }else{										
                                        echo "Đăng Nhập Thất Bại";				
                                    }										   
                            }
                            mysqli_free_result($query);	 	
                        }
                        }
                        mysqli_close($connect);
                                    }	
                                   								   
                              if(  !isset( $_SESSION["username"])){
                      ?> <li class="single-icon">
                            <a href="#" class="nk-sign-toggle no-link-effect" id="LGLU">
                                <span class="nk-icon-toggle">
                                    <span class="nk-icon-toggle-front">
                                        <span class="fa fa-sign-in"></span>
                                    </span>
                                    <span class="nk-icon-toggle-back">
                                        <span class="nk-icon-close"></span>
                                    </span>
                                </span>
                            </a>
                            </li>
                            <?php
                         }  else{

                         
                        
                        ?>
                            <form method="post">
                                <li class="single-icon">

                                    <span style="font-size: 15px; word-wrap: break-word;">Xin chào,<br>
                                        <a href=""><?php echo $_SESSION['username'];?> </a>

                                        <button name="logout" class="">
                                            <i class="fa fa-sign-in"></i>
                                        </button>
                                    </span>

                                </li>
                            </form>
                            <?php } 
                         if(isset($_POST['logout'])){                          
                            session_unset();
                            
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>

    </header>

    <div id="nk-nav-mobile" class="nk-navbar nk-navbar-side nk-navbar-left-side nk-navbar-overlay-content d-lg-none">
        <div class="nano">
            <div class="nano-content">
                <a href="trangchu.php" class="nk-nav-logo">
                    <!-- <img src="assets/images/logo.svg" alt="" width="90"> -->
                    Vĩnh Hằng
                </a>
                <div class="nk-navbar-mobile-content">
                    <ul class="nk-nav">
                        <!-- Here will be inserted menu from [data-mobile-menu="#nk-nav-mobile"] -->
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-main">

        <div class="nk-header-title nk-header-title-sm nk-header-title-parallax nk-header-title-parallax-opacity">
            <div class="bg-image">
                <!-- <img src="assets/images/image-1.jpg" alt="" class="jarallax-img"> -->
            </div>
            <div class="nk-header-table">
                <div class="nk-header-table-cell">
                    <div class="container">
                        <h1 class="nk-title"><?php 
                           $sql = "SELECT *FROM khumo ";
                           $query = mysqli_query($connect,$sql);
                           $result= mysqli_num_rows($query);
                           if($query){
                               while ( $data =mysqli_fetch_array($query) ) {
                        if($dao == $data[3]){

                            $sql = "SELECT *FROM khumo where MaKM='$idkm' and Dao='$dao'";
                            $query = mysqli_query($connect,$sql);
                            $result= mysqli_num_rows($query);
                            if($query){
                                while ( $data =mysqli_fetch_array($query) ) {
                            echo $data[1]. " - " . $data[3];
                                }
                            }

                            }else{
                                $sql = "SELECT *FROM khumo where MaKM='$idkm' and Dao1='$dao'";
                            $query = mysqli_query($connect,$sql);
                            $result= mysqli_num_rows($query);
                            if($query){
                                while ( $data =mysqli_fetch_array($query) ) {
                            echo $data[1]. " - " . $data[4];
                                }
                            }
                                }
                            }
                        }

                        
                           ?></h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="nk-gap-4"></div>
        <div class="container">
            <div class="row vertical-gap lg-gap">

                <!--                 -->
                <?php
                
            $sql = "SELECT *FROM mo ";
            $query = mysqli_query($connect,$sql);
            $result= mysqli_num_rows($query);
            if($query){
                while ( $mo =mysqli_fetch_array($query) ) {   
                    if(!isset( $_SESSION["emailg"]) && $mo[13] == "Công Khai" || isset( $_SESSION["emailg"])== $mo[3]){         
                 if($mo[9]== $dao && $mo[12]== $idkm ){
                 
                if($mo[10] == "4.jpg"){
               ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class="nk-image-box-3 nk-no-effect hover">
                        <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                            id="hinhshow">
                        <p class="text-block"><?php echo $mo[2]; ?></p>
                        <p class="textyear" id="year" style="color: white;">
                            <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                    </div>
                </div>
                <?php }else if($mo[10] == "1.jpg"){
                ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class="nk-image-box-3 nk-no-effect hover">
                        <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                            id="hinhshow">
                        <p class="text-block"><?php echo $mo[2]; ?></p>
                        <p class="textyear" id="year">
                            <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                    </div>
                </div>
                <?php  }else if($mo[10] == "8.jpg"){
                        ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class="nk-image-box-3 nk-no-effect hover">
                        <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                            id="hinhshow">
                        <p class="text-block" style="bottom: 25px;"><?php echo $mo[2]; ?></p>
                        <p class="textyear" id="year" style="color: white;">
                            <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                    </div>
                </div>
                <?php  }else if($mo[10]=="3.jpg"){
                            ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class="nk-image-box-3 nk-no-effect hover">
                        <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                            id="hinhshow">
                        <p class="text-block" style="bottom: 65px;"><?php echo $mo[2]; ?></p>
                        <p class="textyear" id="year" style="color: white; bottom:-15px;">
                            <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                    </div>
                </div>
                <?php  } else if($mo[10]=="5.jpg"){
                    ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class="nk-image-box-3 nk-no-effect hover">
                        <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                            id="hinhshow">
                        <p class="text-block" style="bottom: 45px; right: 10px;"><?php echo $mo[2]; ?></p>
                        <p class="textyear" id="year" style="color: white; bottom:-5px;">
                            <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                    </div>
                </div>

                <?php }  else if($mo[10] =="6.jpg"){
                    ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class="nk-image-box-3 nk-no-effect hover">
                        <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                            id="hinhshow">
                        <p class="text-block" style="bottom: 85px; right: 10px;"><?php echo $mo[2]; ?></p>
                        <p class="textyear" id="year" style="color: white; bottom:-10px;">
                            <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                    </div>
                </div>

                <?php  }else if($mo[10]=="7.jpg"){
                    ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class="nk-image-box-3 nk-no-effect hover">
                        <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                            id="hinhshow">
                        <p class="text-block" style="bottom: 85px; right: 10px;"><?php echo $mo[2]; ?></p>
                        <p class="textyear" id="year" style="color: white; bottom:5px;">
                            <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                    </div>
                </div>
                <?php } //hàm if so sánh file hình            
                            }//Hàm if show
                        }else if(isset( $_SESSION["emailg"])== $mo[3] && $mo[13] == "Công Khai"){//Hàm chế độ công khai và riêng tư
                            if($mo[9]== $dao && $mo[12]== $idkm ){              
                                if($mo[10] == "4.jpg"){
                        ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class="nk-image-box-3 nk-no-effect hover">
                        <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                            id="hinhshow">
                        <p class="text-block"><?php echo $mo[2]; ?></p>
                        <p class="textyear" id="year" style="color: white;">
                            <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                    </div>
                </div>
                <?php }else if($mo[10] == "1.jpg"){
                ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class="nk-image-box-3 nk-no-effect hover">
                        <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                            id="hinhshow">
                        <p class="text-block"><?php echo $mo[2]; ?></p>
                        <p class="textyear" id="year">
                            <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                    </div>
                </div>
                <?php  }else if($mo[10] == "8.jpg"){
                        ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class="nk-image-box-3 nk-no-effect hover">
                        <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                            id="hinhshow">
                        <p class="text-block" style="bottom: 25px;"><?php echo $mo[2]; ?></p>
                        <p class="textyear" id="year" style="color: white;">
                            <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                    </div>
                </div>
                <?php  }else if($mo[10]=="3.jpg"){
                            ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class="nk-image-box-3 nk-no-effect hover">
                        <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                            id="hinhshow">
                        <p class="text-block" style="bottom: 65px;"><?php echo $mo[2]; ?></p>
                        <p class="textyear" id="year" style="color: white; bottom:-15px;">
                            <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                    </div>
                </div>
                <?php  } else if($mo[10]=="5.jpg"){
                    ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class="nk-image-box-3 nk-no-effect hover">
                        <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                            id="hinhshow">
                        <p class="text-block" style="bottom: 45px; right: 10px;"><?php echo $mo[2]; ?></p>
                        <p class="textyear" id="year" style="color: white; bottom:-5px;">
                            <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                    </div>
                </div>

                <?php }  else if($mo[10] =="6.jpg"){
                    ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class="nk-image-box-3 nk-no-effect hover">
                        <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                            id="hinhshow">
                        <p class="text-block" style="bottom: 85px; right: 10px;"><?php echo $mo[2]; ?></p>
                        <p class="textyear" id="year" style="color: white; bottom:-10px;">
                            <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                    </div>
                </div>

                <?php  }else if($mo[10]=="7.jpg"){
                    ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class="nk-image-box-3 nk-no-effect hover">
                        <a href="mochitiet.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $mo[9];?>&ID=<?php echo $mo[0];?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/<?php echo $mo[10]; ?>" data-from='1.1' alt="" style=" width: 150px;"
                            id="hinhshow">
                        <p class="text-block" style="bottom: 85px; right: 10px;"><?php echo $mo[2]; ?></p>
                        <p class="textyear" id="year" style="color: white; bottom:5px;">
                            <?php echo date("d/m/Y", strtotime($mo[5])); ?></p>

                    </div>
                </div>
                <?php
                                }//hàm if so sánh file hình
                            }//Hàm if show
                        }//Hàm chế độ công khai và riêng tư
                    ?>
                <?php     
                        }//Hàm truy xuất db
                    }//Hàm truy xuất db
                    
                   ?>
                <!--                 -->
                <?php 
                
            for( $i = 1; $i<=42; $i++){
                ?>
                <div class="col-md-5 col-lg-4" style="padding-left: 150px;">
                    <div class=" nk-no-effect hover">
                        <?php 
                    if(!isset($_SESSION['username'])){               
                    ?>
                        <!--                 -->
                        <img src="assets/images/1.jpg" data-from='1.1' alt="" style=" width: 150px;">
                        <div class="nk-image-box-overlay nk-image-box-bottom" style=" width: 150px;">
                            <h3 class="nk-image "
                                style="left: 20px; bottom: 80px; font-size: 12px; position: relative; color: black;">
                                Bạn
                                Cần Đăng Nhập <br> Mới Có Thể Lập Mộ</h3>
                        </div>
                        <?php
                       }else{
                    
                    ?>
                        <!--                 -->
                        <a href="newheadstone.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $_GET['Dao1'];?>&numberstone=<?php echo $i;?>"
                            class="nk-image-box-link"></a>
                        <img src="assets/images/1.jpg" data-from='1.1' alt="" style=" width: 150px;">
                        <div class="nk-image-box-overlay nk-image-box-bottom" style=" width: 150px;">
                            <div>
                                <h3 class="nk-image "> <a
                                        href="newheadstone.php?name=<?php echo $_GET['name'];?>&ten=<?php echo $_GET['ten'];?>&KMID=<?php echo $_GET['KMID'];?>&Dao=<?php echo $_GET['Dao'];?>&Dao1=<?php echo $_GET['Dao1'];?>&numberstone=<?php echo $i;?>"
                                        class="nk-btn nk-btn-xs nk-btn-circle nk-btn-3d nk-btn-color-main-1"
                                        style="left: 15px; bottom: 80px;">Lập Mộ Ngay!</a></h3>

                            </div>
                        </div>
                        <?php }?>

                    </div>
                </div>
                <?php } ?>
                <div class="nk-gap-4"></div>
            </div>
        </div>
        <div class="nk-gap-4"></div>
        <div class="nk-gap-4"></div>


        <footer class="nk-footer nk-footer-parallax nk-footer-parallax-opacity">
            <img class="nk-footer-top-corner" src="assets/images/footer-corner.png" alt="">
            <div class="container">
                <div class="nk-gap-2"></div>

                <div class="nk-gap"></div>
                <p> &copy; 2020 Design by nK Group Inc. </p>
                <div class="nk-gap-4"></div>
            </div>
        </footer>

    </div>

    <div class="nk-share-buttons nk-share-buttons-left d-none d-md-flex">
        <ul>
            <li>
                <span class="nk-share-icon" title="Share page on Facebook" data-share="facebook">
                    <span class="icon fa fa-facebook"></span>
                </span>
                <span class="nk-share-name">Facebook</span>
            </li>
            <li>
                <span class="nk-share-icon" title="Share page on Twitter" data-share="twitter">
                    <span class="icon fa fa-twitter"></span>
                </span>
                <span class="nk-share-name">Twitter</span>
            </li>


        </ul>
    </div>

    <div class="nk-side-buttons nk-side-buttons-visible">
        <ul>
            <li>

            </li>
            <li>
                <span class="nk-btn nk-btn-lg nk-btn-icon nk-bg-audio-toggle">
                    <span class="icon">
                        <span class="ion-android-volume-up nk-bg-audio-pause-icon"></span>
                        <span class="ion-android-volume-off nk-bg-audio-play-icon"></span>
                    </span>
                </span>
            </li>
            <li class="nk-scroll-top">
                <span class="nk-btn nk-btn-lg nk-btn-icon">
                    <span class="icon ion-ios-arrow-up"></span>
                </span>
            </li>
        </ul>
    </div>

    <div class="nk-search">
        <div class="container">
            <form action="#">
                <fieldset class="form-group nk-search-field">
                    <input type="text" class="form-control" id="searchInput" placeholder="Search..." name="s">
                    <label for="searchInput"><i class="ion-ios-search"></i></label>
                </fieldset>
            </form>
        </div>
    </div>

    <div class="nk-sign-form" id="sign">
        <div class="nk-gap-5"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 offset-lg-4 col-md-6 offset-md-3">
                    <div class="nk-sign-form-container">
                        <div class="nk-sign-form-toggle h3">
                            <a href="#" class="nk-sign-form-login-toggle active">Đăng Nhập</a>
                            <a href="#" class="nk-sign-form-register-toggle">Đăng Ký</a>
                        </div>
                        <div class="nk-gap-2"></div>

                        <form class="nk-sign-form-login active" method="POST">
                            <input class="form-control" type="text" placeholder="Username " name="username">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="password" placeholder="Password" name="password">
                            <div class="nk-gap-2"></div>
                            <div class="form-check float-left">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input"> Remember Me </label>
                            </div>
                            <button class="nk-btn nk-btn-color-white link-effect-4 float-right" name="login">Đăng
                                Nhập</button>
                            <div class="clearfix"></div>
                            <div class="nk-gap-1"></div>
                            <a class="nk-sign-form-lost-toggle float-right" href="#">Quên Mật Khẩu?</a>
                        </form>

                        <form class="nk-sign-form-lost" action="#">
                            <input class="form-control" type="text" placeholder="Username or Email">
                            <div class="nk-gap-2"></div>
                            <button class="nk-btn nk-btn-color-white link-effect-4 float-right">Đổi Mật
                                Khẩu</button>
                        </form>

                        <form class="nk-sign-form-register" method="POST">
                            <input class="form-control" type="text" placeholder="Username" name="username">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="password" placeholder="Mật Khẩu" name="password">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="email" placeholder="Email" name="email">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="text" placeholder="Họ Và Tên" name="hovaten">
                            <div class="nk-gap-2"></div>
                            <input class="form-control" type="tel" placeholder="Điện Thoại" name="dienthoai"
                                maxlength="10">
                            <div class="nk-gap-2"></div>

                            <button class="nk-btn nk-btn-color-white link-effect-4 float-right" name="register">Đăng
                                Ký</button>

                        </form>
                        <?php 
                         if(isset($_POST['register'])){
							$username= $_POST['username'];
							$matkhau =$_POST['password'];
                            $email= $_POST['email'];
                            $dta = $_POST['dienthoai'];
                           $hvt =$_POST['hovaten'];
                    		if($username ==""|| $matkhau==""|| $email == "" || $dta =="" ||  $hvt==""){
								echo "Vui lòng nhập đầy đủ thông tin";
                            }  else  {
								
								$sql = ("INSERT INTO account(Username, Password, Email, DienThoai,HovaTen) VALUES ('$username','$matkhau','$email','$dta',' $hvt')");
								$query = mysqli_query($connect,$sql);
                                   echo " Đăng Ký Thành Công!";                   
                                      header("Location: http://localhost/NghiaTrangOnline1/trangchu.php");

										}									   
                                    }	
                                
					
                            ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="nk-gap-5"></div>
    </div>
    <!-- END: Sign Form -->
    <!-- START: Scripts -->
    <!-- Object Fit Polyfill -->
    <script src="assets/vendor/object-fit-images/dist/ofi.min.js"></script>
    <!-- GSAP -->
    <script src="assets/vendor/gsap/dist/gsap.min.js"></script>
    <script src="assets/vendor/gsap/dist/ScrollToPlugin.min.js"></script>
    <!-- Popper -->
    <script src="assets/vendor/popper.js/dist/umd/popper.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/vendor/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Sticky Kit -->
    <script src="assets/vendor/sticky-kit/dist/sticky-kit.min.js"></script>
    <!-- Jarallax -->
    <script src="assets/vendor/jarallax/dist/jarallax.min.js"></script>
    <script src="assets/vendor/jarallax/dist/jarallax-video.min.js"></script>
    <!-- imagesLoaded -->
    <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
    <!-- Flickity -->
    <script src="assets/vendor/flickity/dist/flickity.pkgd.min.js"></script>
    <!-- Isotope -->
    <script src="assets/vendor/isotope-layout/dist/isotope.pkgd.min.js"></script>
    <!-- Photoswipe -->
    <script src="assets/vendor/photoswipe/dist/photoswipe.min.js"></script>
    <script src="assets/vendor/photoswipe/dist/photoswipe-ui-default.min.js"></script>
    <!-- Typed.js -->
    <script src="assets/vendor/typed.js/lib/typed.min.js"></script>
    <!-- Jquery Validation -->
    <script src="assets/vendor/jquery-validation/dist/jquery.validate.min.js"></script>
    <!-- Jquery Countdown + Moment -->
    <script src="assets/vendor/jquery-countdown/dist/jquery.countdown.min.js"></script>
    <script src="assets/vendor/moment/min/moment.min.js"></script>
    <script src="assets/vendor/moment-timezone/builds/moment-timezone-with-data.min.js"></script>
    <!-- Hammer.js -->
    <script src="assets/vendor/hammerjs/hammer.min.js"></script>
    <!-- NanoSroller -->
    <script src="assets/vendor/nanoscroller/bin/javascripts/jquery.nanoscroller.js"></script>
    <!-- SoundManager2 -->
    <script src="assets/vendor/soundmanager2/script/soundmanager2-nodebug-jsmin.js"></script>
    <!-- DateTimePicker -->
    <script src="assets/vendor/jquery-datetimepicker/build/jquery.datetimepicker.full.min.js"></script>
    <!-- Revolution Slider -->
    <script src="assets/vendor/revolution/js/jquery.themepunch.tools.min.js"></script>
    <script src="assets/vendor/revolution/js/jquery.themepunch.revolution.min.js"></script>
    <script src="assets/vendor/revolution/js/extensions/revolution.extension.video.min.js"></script>
    <script src="assets/vendor/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
    <script src="assets/vendor/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
    <!-- Keymaster -->
    <script src="assets/vendor/keymaster/keymaster.js"></script>
    <!-- Summernote -->
    <script src="assets/vendor/summernote/dist/summernote-bs4.min.js"></script>
    <!-- GODLIKE -->
    <script src="assets/js/godlike.min.js"></script>
    <script src="assets/js/godlike-init.js"></script>
    <!-- END: Scripts -->
    <style>
    .text-block {
        position: absolute;
        bottom: 45px;
        background-color: none;
        background-position: center center;
        color: sienna;
        left: 20px;

        text-align: center;
        padding-right: 70px;
        padding-left: 10px;
    }

    .textyear {
        position: absolute;
        bottom: -20px;
        left: 47px;
        color: black;
        font-size: 12px;
    }
    </style>
</body>

</html>